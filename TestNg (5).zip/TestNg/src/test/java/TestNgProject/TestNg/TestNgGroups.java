package TestNgProject.TestNg;

import org.testng.annotations.Test;

public class TestNgGroups {

	@Test(groups= {"demo"})
	public void startingpoint()
	{
		System.out.println("Hello I am starting point");
	}
	
	@Test(groups= {"demo"})
	public void checktitle()
	{
		System.out.println("Hello I am chektitle");
	}
	
	@Test(groups= {"sanity"})
	public void Homepageclick()
	{
		System.out.println("Hello I am homepage click");
	}
	
	@Test(groups= {"sanity"})
	public void Addtocarpageclick()
	{
		System.out.println("Hello I am add to cart page click");
	}
	
	@Test(groups= {"demo1"})
	public void checktitle2()
	{
		System.out.println("Hello I am chektitle 2");
	}
	
	@Test(groups= {"demo2"})
	public void checktitle3()
	{
		System.out.println("Hello I am chektitle 3");
	}
	

}
