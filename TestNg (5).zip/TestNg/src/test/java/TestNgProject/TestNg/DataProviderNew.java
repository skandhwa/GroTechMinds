package TestNgProject.TestNg;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderNew {
	
	@DataProvider(name="abcd")
	public Object[][] dpmethod()
	{
		return new Object[][] {{2,3,5},{5,7,9}};
	}
		
	@Test(dataProvider="abcd")
	public void test(int a,int b,int result)
	{
		int sum=a+b;
		Assert.assertEquals(result, sum);
	}

}
