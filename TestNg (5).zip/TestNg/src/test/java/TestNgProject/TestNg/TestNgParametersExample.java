package TestNgProject.TestNg;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParametersExample {
	
	@Test(priority=2)
	@Parameters({"val1","val2"})
	public void sum(int v1,int v2)
	{
		int finalsum=v1+v2;
		System.out.println("Sum is " +finalsum);
	}
	
	@Test
	@Parameters({"val1","val2"})
	public void Difference(int v1,int v2)
	{
		int finaldiff=v1-v2;
		System.out.println("Difference is " +finaldiff);
	}

}
