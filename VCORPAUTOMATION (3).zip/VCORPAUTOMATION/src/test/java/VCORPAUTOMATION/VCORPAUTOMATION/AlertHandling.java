package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AlertHandling {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://demo.automationtesting.in/Alerts.html");
		Thread.sleep(3000);
//		driver.findElement(By.xpath("//a[@href='#OKTab']")).click();
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(3000);
//		///SIMPLE ALERT
//		driver.switchTo().alert().accept();
		
		///CONFIRMATION ALERT 
		
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(3000);
//	String text=	driver.findElement(By.xpath("//p[@id='demo']")).getText();
//	Thread.sleep(3000);
//	System.out.println(text);
//	driver.navigate().refresh();
//	driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//	Thread.sleep(3000);
//	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//	Thread.sleep(3000);
//	driver.switchTo().alert().dismiss();
//	Thread.sleep(3000);
//   String text1=	driver.findElement(By.xpath("//p[@id='demo']")).getText();
//   Thread.sleep(3000);
//   System.out.println(text1);
   
   
   ////PROMPT ALERT 
   
   driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
   Thread.sleep(3000);
   driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
   Thread.sleep(3000);
   Alert alert=driver.switchTo().alert();
   Thread.sleep(3000);
   alert.sendKeys("Saurabh");
   Thread.sleep(3000);
   alert.accept();
   String text1=driver.findElement(By.xpath("//p[@id='demo1']")).getText();
   Thread.sleep(3000);
   System.out.println(text1);
	
   driver.navigate().refresh();
		
   driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
   Thread.sleep(3000);
   driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
   Thread.sleep(3000);
   Alert alert1=driver.switchTo().alert();
   Thread.sleep(3000);
   alert1.sendKeys("Saurabh");
   Thread.sleep(3000);
   alert1.dismiss();
  // String text2=	driver.findElement(By.xpath("//p[@id='demo']")).getText();
   //Thread.sleep(3000);
   System.out.println("This is Empty as you pressed cancel");
		
		
		

	}

}
