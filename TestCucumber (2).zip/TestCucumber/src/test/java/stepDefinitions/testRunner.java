package stepDefinitions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/resources",
glue= {"stepDefinitions"},monochrome=true,
tags="@regression",

plugin= {"pretty","html:target/HtmlReports/index.html",
		"json:target/CucumberReports/cucumber.json"}



		



)


public class testRunner extends AbstractTestNGCucumberTests{

}
