package Constants;

public class Constant {
	
	public static final String TESTDATAPATH="C:\\Users\\saura\\OneDrive\\Documents\\TestData2607.xlsx";
	public static final String SCREENSHOTPATH="E:\\TakeScreenShot\\"+Math.random()+"test.jpg";

}
