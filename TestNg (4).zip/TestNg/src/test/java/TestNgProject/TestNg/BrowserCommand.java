package TestNgProject.TestNg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserCommand {
	
	@Test
	public void addtest()
	{
		WebDriver driver=new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		
	}

}
