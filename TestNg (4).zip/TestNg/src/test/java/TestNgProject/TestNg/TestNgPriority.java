package TestNgProject.TestNg;
import org.testng.annotations.Test;
public class TestNgPriority {
	
		 @Test(priority=0)
	 public void testCase1() {
	   System.out.println("This is test case 1"); //1
	 }
	 
		 @Test(priority=-2)
	 public void testCase2() {
	   System.out.println("This is test case 2"); //2
	 }
	 
	 @Test(priority=-5)
	 public void testCase3() {
	   System.out.println("This is test case 3"); //3
	 }

	 @Test(priority=3)
	 public void BtestCase() {
	   System.out.println("This is test case 4"); //4
	 }
	 @Test(priority=3)
	 public void BtestCaseQ() {
	   System.out.println("This is test case 5"); //5
	 }
	 @Test
	 public void CtestCase() {
	   System.out.println("This is test case 6"); //6
	 }
	 
}
