package GroTechLatest;

public class Testnew {
	
	void display()
	{
		int x=10;
		int y=5;
		int z=x+y;
		System.out.println(z);
		
	}
	
	int display2()
	{
		int c=10;
		int d=5;
		int e=c-d;
		System.out.println(e);
		return e;
	}
	
	

	public static void main(String[] args) {
		Testnew obj=new Testnew();
		obj.display();

	}

}
