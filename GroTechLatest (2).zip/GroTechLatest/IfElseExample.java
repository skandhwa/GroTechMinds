package GroTechLatest;

public class IfElseExample {

	public static void main(String[] args) {
		
		int n1=200,n2=100,n3=1000;
		
		if(n1>n2)////200>100
			
		{
			
			if(n1>n3)///200>1000
				System.out.println("n1 is largest");
			
			
			else
				System.out.println("n3 is largest");
		}
		
		
		else
		{
			if(n2>n3)//100>1000
				System.out.println("n2 is largest");
			else
				System.out.println("n3 is largest");
		}
			
		
		

	}

}
