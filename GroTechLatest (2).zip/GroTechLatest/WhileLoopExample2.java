package GroTechLatest;

public class WhileLoopExample2 {

	public static void main(String[] args) {
		
		int i=10;///initialization 
		
		while(i>5)//Condition checking
		{
			System.out.println(i);
			i--;///Increment/decrement
			
		}
		

	}

}
