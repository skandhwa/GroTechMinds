package GroTechLatest;

public class Method2 {
     
	public int main()
	{
		int x=6;
		int y=9;
		int z=x+y;
		return z;
		
	}
	
	
	
	public static void main(String[] args) {
		
		Method2 obj=new Method2();
		System.out.println(obj.main());
		
		
		
		
		

	}

}
