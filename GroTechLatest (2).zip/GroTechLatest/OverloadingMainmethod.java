package GroTechLatest;

public class OverloadingMainmethod {
   
	
	
	public static int main(int c,int d)
	{
		 int u=10;
		
		return c+d;
		
	}
	
	static 
	{
		for(int i=0;i<5;i++)
		{
			System.out.println(i);
		}
		System.out.println("hello");
	}
	
	
	
	public static void main(String[] args) {
		
		System.out.println(OverloadingMainmethod.main(4,7));
	}

}
