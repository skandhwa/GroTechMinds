package GroTechLatest;

public class Operators {

	public static void main(String[] args) {
		
//		int x=5;
//		
////		x++;///postfix increment
////		x--;//postfix decrement
////		++x; ///prefix increment 
//		
//		int y;
//		
//		y=++x;
//		System.out.println(y);
//		
//		
//		int r=4;
//		int z;
//		z=r++;
//		System.out.println(z);
		
		
		int r=5;
		int s=4;
		int f= r++   -   ++s   +  ++r;  //5 
		
		int h= r++ - s++ + r++;/// 5 - 4 + 6
		
		
		
		
		
		
		//++6=7 /// 5-5+7
		
		
		
		
		
		

	}

}
