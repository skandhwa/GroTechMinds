package GroTechLatest;


class DZ
{
	int add(int a,int b)
	{
		return a+b;
		
	}
	
	double add(int c,float d)
	{
		return c+d;
	}
}

public class OverloadingNext {

	public static void main(String[] args) {
		
		DZ obj=new DZ();
	System.out.println(	obj.add(56, 89));
	System.out.println(	obj.add(45, 23.5f));
		

	}

}
