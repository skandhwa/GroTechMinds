package GroTechLatest;

public class doWhileExample {

	public static void main(String[] args) {
		
		int i=5;
		do
		{
			System.out.println(i);//5//4//3//2
			i--;//5--//4--//3--//2--
		}
		
		while(i>1);////Exit point of the program //4>1//3>1//2>1//1>1
		
			
	
		

	}

}
