package GroTechLatest;

public class PatternPrinting {

	public static void main(String[] args) {
		
		int i,j,row=5;
		
		for(i=0;i<row;)//i=1,1<5//i=2,2<5//i=3,3<5
			
		{
			for(j=0;j<=i;)///j=0,0<=3
			{
				System.out.print("*");
				j++;
			}
			
			i++;//1++//2++
			
			System.out.println();//
			
		}
		

	}

}
