package GroTechLatest;

public class BX {
	
	int id;
	String name;
	float m;
	
	
	
	void display()
	{
		int x=10;
		//float m=20;
		int y=20;
		int z=x+y;
		System.out.println(z);
		System.out.println(id);
		System.out.println(name);
		System.out.println(m);
	}
	
	public static void main(String[] args) {
		
		
		
		BX obj=new BX();
		obj.display();
		

	}

}
