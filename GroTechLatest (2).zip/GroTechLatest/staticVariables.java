package GroTechLatest;

public class staticVariables {
	
	int rollno;
	String name;
	static String college="IIT Delhi";
	
	staticVariables(int r,String n)
	{
		rollno=r;
		name=n;
	}
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+college);
	}
	

	public static void main(String[] args) {
		
		staticVariables obj=new staticVariables(1234,"Saurabh");
		staticVariables obj1=new staticVariables(3456,"Gaurabh");
		staticVariables obj2=new staticVariables(7654,"Samir");
		staticVariables obj3=new staticVariables(1284,"Samresh");
		
		staticVariables.college="IIT Mumbai";
		
		
		obj.display();
		obj1.display();
		obj2.display();
		obj3.display();
		
		
		
		
		
		

	}

}
