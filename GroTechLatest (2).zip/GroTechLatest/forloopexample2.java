package GroTechLatest;

public class forloopexample2 {

	public static void main(String[] args) {
		int sum=0;
		int n=5;
		
		
		for(int i=1;i<n;)//i=1;1<5//i=2,2<5//i=3,3<5//i=4,4<5//i=5,5<5
		{
			sum=sum+i;//sum=0+1=1//sum=1+2=3//sum=3+3=6//sum=6+4=10
			i++;//1++//2++//3++//4++
		}
		
		
		System.out.println(sum);

	}

}
