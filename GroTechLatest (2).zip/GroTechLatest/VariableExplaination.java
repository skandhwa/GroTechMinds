package GroTechLatest;

public class VariableExplaination {
	
	public int x=10;
	static int t=18;
	
	int display()
	{
	     x=x;
		int x=5;
		int y=10;
		int z=x+y;
		int w=t-x;
		return z;
		//System.out.println(z);///Local Variables
	}
	
	int r=4;

	
	

	public static void main(String[] args) {
		
		
		
		

	}

}
