package GroTechLatest;

class Animal2
{
	void eat()
	{
		System.out.println("I am eating");
	}
}

class Dog2 extends Animal2
{
	void eat()
	{
		System.out.println("Dog is eating");
	}
	
	void bark()
	{
		System.out.println("Dog is barking");
	}
	
	void workforall()
	{
		
		bark();
		eat();
		super.eat();
		
		
	}
}
public class SuperforMethod {

	public static void main(String[] args) {
		
		Dog2 obj=new Dog2();
		obj.workforall();
		
		

	}

}
