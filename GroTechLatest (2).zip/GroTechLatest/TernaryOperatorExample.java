package GroTechLatest;

public class TernaryOperatorExample {

	public static void main(String[] args) {
		
		int a=200;
		int b=30;
		int c=60;
		
		int result= c<b ? c:b;//60<30 ? 60:30
		
		System.out.println(result);
		
		int e= 67;
		e*=15;///e=e*15;
		System.out.println(e);
		
		
	
	
	
	
	
	

	}

}
