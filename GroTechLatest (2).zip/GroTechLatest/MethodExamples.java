package GroTechLatest;

class AX
{
	public float display()
	{
		int x=3489;
		int y=67;
		int z=x/y;
		return z;
	}
}

public class MethodExamples {

	public static void main(String[] args) {
		
		AX obj=new AX();
   System.out.println( obj.display());
		
	

	}

}
