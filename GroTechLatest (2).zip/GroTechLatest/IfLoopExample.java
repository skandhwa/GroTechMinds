package GroTechLatest;

public class IfLoopExample {

	public static void main(String[] args) {
		
		int a=100;
		int b=20;
		
		if(a>b)
		{
			System.out.println("a islargest");
			
		}
		
		else
			System.out.println("b islargest");
			
			
		
		

	}

}
