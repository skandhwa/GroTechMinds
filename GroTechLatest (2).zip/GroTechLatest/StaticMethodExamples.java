package GroTechLatest;

class AT
{
	static int g=9;
	static int add(int a,int b)
	{
		return a+b;
		
	}
	
	static int sub(int c,int d)
	{
		return c-d;
	}
	
	void display()
	{
		System.out.println("Hello");
	}

}

public class StaticMethodExamples {
	
	public static void main(String[] args) {
		
//	AT obj=new AT();
//	System.out.println(	obj.add(3, 4));
//	System.out.println	(obj.sub(5, 2));
		
		
		System.out.println(		AT.add(4, 5));
		System.out.println(	AT.sub(9, 5));
	
		

	}

}
