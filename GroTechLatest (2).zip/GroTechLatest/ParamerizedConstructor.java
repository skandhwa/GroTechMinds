package GroTechLatest;

public class ParamerizedConstructor {
	
	int id;
	String name;
	
	ParamerizedConstructor(int i, String n)
	{
		id=i;
		name=n;
		int k=10;
		System.out.println(id);
		System.out.println(name);
	}
	
//	void display()
//	{
//		System.out.println(id + ""+name);
//	}
	
	public static void main(String[] args) {
		
		ParamerizedConstructor obj=new ParamerizedConstructor(10,"Saurabh");
		ParamerizedConstructor obj2=new ParamerizedConstructor(11,"Gaurabh");
		ParamerizedConstructor obj3=new ParamerizedConstructor(12,"Aman");
		ParamerizedConstructor obj4=new ParamerizedConstructor(13,"tapan");
		ParamerizedConstructor obj5=new ParamerizedConstructor(14,"Saurabh");
		
		
          
	}

}
