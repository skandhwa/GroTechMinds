package GroTechLatest;

public class OperatorsExamples {

	public static void main(String[] args) {
		int a= 6;
		int b=8 ;
		int c=10;
		
		int r= ++a - --c + ++a + c++ - --b + a++ + c--;
		
		// 7-9+8+10-7+10+9
		
		System.out.println(r);
		
		
		///> < >= <= ==
		
		int y=34;
		int z=y%7;
		int h=y/7;
		System.out.println(z);
		System.out.println(h);
		
		
		System.out.println(5<<3);//// 5*2^3
		System.out.println(7>>2);////7/2^2
		
		int p=9;///Assingment Operator
		int k=3*3;
		
		if(p==k)
		{
			System.out.println("True");
		}
		
		
		
		
		
		
		
		

	}

}
