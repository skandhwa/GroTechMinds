package GroTechLatest;

public class SumofNumbers {

	public static void main(String[] args) {
		
		int i=5;
		int sum=0;
		
		do
		{
			sum=sum+i;///sum=0+5//sum=5+6=11//sum=11+6//sum=17+7
			i++;//5++
			
		}
		
		while(i<10);//5<10//6<10//7<10
		
		
		System.out.println(sum);
			
		

	}

}
