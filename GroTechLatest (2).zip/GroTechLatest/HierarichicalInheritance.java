package GroTechLatest;

class Animal
{
	void eat()
	{
		System.out.println("eating");
	}
}

class cat extends Animal
{
	void run()
	{
		System.out.println("cat is running");
	}
}

class Dog extends Animal
{
	void bark()
	{
		System.out.println("Dog is barking");
	}
}


public class HierarichicalInheritance {

	public static void main(String[] args) {
		
		cat obj=new cat();
		obj.eat();
		obj.run();
		
		
		Dog obj1=new Dog();
		obj1.bark();
		obj1.eat();
		

	}

}
