package GroTechLatest;

class DX
{
	public int addition()
	{
		int a=10;
		int b=20;
		int c=a+b;
		return c;
	}
}
class DY extends DX///DY is the child class(subclass) and DX is the parent class(super class) 
{
	void display()
	{
		System.out.println ("Hello");
	}
}
public class InheritanceExamples {

	public static void main(String[] args) {
              
		DY obj=new DY();
		System.out.println(  obj.addition());
		obj.display();

	}

}
