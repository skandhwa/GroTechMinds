package GroTechLatest;

public class datatypeExamples {
	
	int x=5;
	void display()
	{
		System.out.println(this.x);
		int x=10;
		System.out.println(x);
	}

	public static void main(String[] args) {
		
		datatypeExamples obj=new datatypeExamples();
		obj.display();
		

		
		
		
		

	}

}
