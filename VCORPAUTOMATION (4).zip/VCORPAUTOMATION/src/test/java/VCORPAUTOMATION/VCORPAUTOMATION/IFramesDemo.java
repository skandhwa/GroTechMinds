package VCORPAUTOMATION.VCORPAUTOMATION;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class IFramesDemo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://demo.automationtesting.in/Frames.html");
		Thread.sleep(3000);
		
	List<WebElement>li=	driver.findElements(By.tagName("iframe"));
	
	int x=li.size();
	System.out.println(x);
	for(WebElement a:li)
	{
	String val=	a.getText();
	System.out.println(val);
	}
	
	
	driver.switchTo().frame("singleframe");
	Thread.sleep(3000);
	driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Saurabh");
	Thread.sleep(3000);
	
	driver.switchTo().defaultContent();
	
	driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Saurabh");
	
		
		

	}

}
