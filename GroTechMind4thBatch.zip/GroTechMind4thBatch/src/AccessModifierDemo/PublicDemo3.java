package AccessModifierDemo;

import GroTechLatest.PublicAccessModifier;

public class PublicDemo3 {

	public static void main(String[] args) {
		
		PublicAccessModifier obj=new PublicAccessModifier();
		obj.test();

	}

}
