package AccessModifierDemo;

import GroTechLatest.ProtectedDemo1;
import GroTechLatest.ProtectedDemo2;

public class ProtectedDemo3 extends ProtectedDemo1 {

	public static void main(String[] args) {
		
		ProtectedDemo3 obj=new ProtectedDemo3();
		obj.display();
		

	}

}
