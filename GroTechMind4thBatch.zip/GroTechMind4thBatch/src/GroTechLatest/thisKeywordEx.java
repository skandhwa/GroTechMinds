package GroTechLatest;

class Student4
{
	int roll;
	String name;
	float fee;
	
	Student4(int roll,String name,float fee)
	{
		this.roll=roll;
		this.name=name;
		this.fee=fee;
		
	}
	
	
	
	void display()
	{
		System.out.println(roll+ " "+name+" "+fee);
	}
	
}


public class thisKeywordEx {

	public static void main(String[] args) {
		
		Student4 obj=new Student4(123,"samir",5000f);
		Student4 obj1=new Student4(1234,"Manish",7000f);
		obj.display();
		obj1.display();
		

		
		
		
		

	}

}
