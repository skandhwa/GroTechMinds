package GroTechLatest;

public class ShortDataType {

	public static void main(String[] args) {
		
		short x=23456;
		short y=5678;
		int h=1212313214;
		
		int r,d;
		
		long u=234325423423432432434654654654L;
		
		float g=9324324324324343243.8233322343243243243243243243243243243243243243243242342f;
		
		double z=123123213342432433243243243212321.3453454353453453243243244343243243243;
		
		
		
		
		
		///-32768 to +32767
		

	}

}
