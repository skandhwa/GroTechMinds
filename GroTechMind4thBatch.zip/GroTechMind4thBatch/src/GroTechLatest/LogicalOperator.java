package GroTechLatest;

public class LogicalOperator {

	public static void main(String[] args) {
		
		int a=14;
		int b=7;
		int c=9;
		
		if(a>b && !(b<c) || c<a && b>a)//////30>43 || 43<67 || 67<30
		{
			System.out.println("True");
		}
		
		else
			System.out.println("False");
		
		

	}

}
