package GroTechLatest;

public class Whileloopthird {

	public static void main(String[] args) 
	{
		int i=5;//
		int sum=0;
		while(i<10)///5<10//6<10//7<10//8<10//9<10//<10
		{
			sum=sum+i;	///sum=0+5=5//sum=5+6=11//sum=11+7=18//sum=18+8=26//sum=26+9=35
			i++;//5++//6++//7++//8++//9++
			
		}
		
		System.out.println(sum);

	}
	
	

}
