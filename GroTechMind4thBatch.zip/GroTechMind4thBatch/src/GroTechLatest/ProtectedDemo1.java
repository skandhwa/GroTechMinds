package GroTechLatest;

public class ProtectedDemo1 {
	
	protected void display()
	{
		System.out.println("Hello I am protected method");
	}
	

	public static void main(String[] args) {
		
		ProtectedDemo1 obj=new ProtectedDemo1();
		obj.display();
	}

}
