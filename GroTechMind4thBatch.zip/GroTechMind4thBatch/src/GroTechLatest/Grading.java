package GroTechLatest;

public class Grading {

	public static void main(String[] args) {
		 int n=80;
		 int m=60;
		 
		 if(n<80)
		 {
			 System.out.println("fail");
		 }
		 
		 else if(n>20 && n<40 && m<20)
		 {
			 System.out.println("D");
		 }
		 
		 else if(n>40 && n<60 && m>20 && m<30)
		 {
			 System.out.println("D");
		 }

	}

}
