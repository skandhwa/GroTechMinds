package GroTechLatest;

public class PublicAccessModifier {
	
	public void test()
	{
		System.out.println("Hello I am public method");
	}
	

	public static void main(String[] args) {
		
		PublicAccessModifier obj=new PublicAccessModifier();
		obj.test();

	}

}
