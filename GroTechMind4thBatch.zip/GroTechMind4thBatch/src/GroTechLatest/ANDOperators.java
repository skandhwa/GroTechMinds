package GroTechLatest;

public class ANDOperators {

	public static void main(String[] args) {
		
		int x=5,y=8,z=9;
		
		if(x>y || y<z) // 5>8 || 8<9
		{
			System.out.println("Yes");
		}
		
		

	}

}
