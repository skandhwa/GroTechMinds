package GroTechLatest;

public class whileLoopExamples {

	public static void main(String[] args) {
		
		int age=18;
		
		while(age>=18)
		{
			if(age>50)
			System.out.println("You are not allowed alcohol");
			else
			System.out.println("You are allowed");
			break;
		}
		
	}

}
