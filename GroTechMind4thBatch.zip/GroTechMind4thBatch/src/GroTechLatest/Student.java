package GroTechLatest;

public class Student {
	int id;
	String name;
	float b;
	
	 Student(int i,String n )
	{
		id=i;
		name=n;
//		System.out.println("Hello");
	}
	
	Student(int i,String n,float s )
	{
		id=i;
		name=n;
		b=s;
	}
	
	
	void display()
	{
		System.out.println(id+" "+name+" "+b);
	}
	

	public static void main(String[] args) {
		
		Student obj=new Student(111,"samir");
		Student obj2=new Student(112,"saurabh",3.5f);
		obj.display();
		obj2.display();

	}

}
