package GroTechLatest;

final class Bike
{
	void display()
	{
		System.out.println("Hello All");
	}
}

class Vehicle extends Bike
{
	
}



public class FinalClassExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
