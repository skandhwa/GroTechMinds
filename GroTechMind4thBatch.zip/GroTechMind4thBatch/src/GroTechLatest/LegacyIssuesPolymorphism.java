package GroTechLatest;

import java.util.Scanner;

class DQ
{
	static int add()///method signature means the number of parameters in methd and the data type of the parameters
	{
		System.out.println("Enter first number");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println("Enter Second number");
		
		int b=sc.nextInt();
		
		return a+b;
	}
	
	static int add(int a,int b,int c)
	{
		return a+b+c;
	}
}


public class LegacyIssuesPolymorphism {

	public static void main(String[] args) {
		
		
		
		
    System.out.println(DQ.add())  ;
    System.out.println(DQ.add(34, 67,89));
		
		
	}

}
