package GroTechLatest;

public class TypeCasting {

	public static void main(String[] args) {
		
		int x=7;
		float z=x;
		
		System.out.println(z);
		
		
		long m=8;
		int n=(int) m;
		
		
		float p=8.7f;
		double q=p;
		
		double l=9.9787;
		float u=(float)l;
		
		double d=16233.77;
		long k=(long)d;
		
		long j=454654654;
		
		
		
		
		

	}

}
