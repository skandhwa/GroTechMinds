package GroTechLatest;

public class ProtectedDemo2 {

	public static void main(String[] args) {
		
		ProtectedDemo1 obj=new ProtectedDemo1();
		obj.display();
		

	}

}
