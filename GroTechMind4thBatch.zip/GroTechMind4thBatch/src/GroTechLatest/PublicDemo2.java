package GroTechLatest;

public class PublicDemo2 {

	public static void main(String[] args) {
		
		PublicAccessModifier obj=new PublicAccessModifier();
		obj.test();

	}

}
