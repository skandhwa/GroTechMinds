package GroTechLatest;

public class LargestBetween3Numbe {

	public static void main(String[] args) {
		
		int a=20;
		int b=40;
		int c=300;
		
		if(a>b && a>c) ////20>40 
		{
			System.out.println("a is largest");
		}
		
		else if(b>a && b>c)///40>20 && 40>300
		{
			System.out.println("b is largest");
		}
		
		else
			System.out.println("c is largest");
		
		

	}

}
