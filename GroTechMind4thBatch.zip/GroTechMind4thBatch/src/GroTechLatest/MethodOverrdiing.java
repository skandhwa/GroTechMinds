package GroTechLatest;


class Vehicle
{
	
	void run()
	{
		int x=5;
		System.out.println("Vehicle is running");
	}
}

class Bike4 extends Vehicle
{
	
	 void run()
	{
		 int x=5;
		 
		System.out.println("Bike is running");
		System.out.println(x);
		
	}
}

public class MethodOverrdiing {

	public static void main(String[] args) {
		
		Bike4 obj=new Bike4();
		obj.run();
		
		Vehicle obj1=new Vehicle();
		obj1.run();
		
		

	}

}
