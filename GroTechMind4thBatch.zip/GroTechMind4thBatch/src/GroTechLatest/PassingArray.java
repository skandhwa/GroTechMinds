package GroTechLatest;

public class PassingArray {
	
	public static void display(int a[])
	{
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	

	public static void main(String[] args) {
		
		display(new int[] {23,54,12,78});
		
	}

}
