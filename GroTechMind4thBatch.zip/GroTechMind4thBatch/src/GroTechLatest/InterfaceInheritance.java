package GroTechLatest;

interface Pritnatble8
{
	void print();
	void display();
}

interface Showable8 extends Pritnatble8
{
	void show();
	void test();
}


class A14 implements Showable8
{

	@Override
	public void print() {
		
		System.out.println("This is a print method");
		
	}

	@Override
	public void display() {
		System.out.println("This is a display method");
		
	}

	@Override
	public void show() {
		System.out.println("This is a show method");
		
	}

	@Override
	public void test() {
		System.out.println("This is a test method");
		
	}
	
}
public class InterfaceInheritance {

	public static void main(String[] args) {
		
		Showable8 ref=new A14();
		ref.display();
		ref.print();
		ref.show();
		ref.display();
		
		
		
		
		

	}

}
