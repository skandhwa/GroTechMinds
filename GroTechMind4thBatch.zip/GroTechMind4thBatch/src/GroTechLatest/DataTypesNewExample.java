package GroTechLatest;

public class DataTypesNewExample {

	public static void main(String[] args) {
		
		char ch='A';
		System.out.println(ch);
		
		String Name="Saurabh";
		System.out.println(Name);
		
		//x=5;
		//y=8;
		//z=x*y;/// * is the operator
		
		
		
		
		
		
		
		

	}

}
