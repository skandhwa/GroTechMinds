package GroTechLatest;

interface Printable5
{
	void print();
	void test();
}
interface Showable5
{
	void print();
	void display();
}


class Test12 implements Printable5,Showable5
{
	public void print()
	{
		System.out.println("Hello How are you");
	}
	
	public void display()
	{
		System.out.println("I am display method");
	}
	
	public void test()
	{
		System.out.println("I am test method");
	}
}
public class MultipleInheritanceinterface {

	public static void main(String[] args) {
		
		Printable5 obj=new Test12();
		obj.print();
		obj.test();
		
		
		
		Showable5 obj1=new Test12();
		obj1.print();
		obj1.display();
		

	}

}
