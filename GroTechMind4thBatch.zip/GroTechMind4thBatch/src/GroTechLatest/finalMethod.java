package GroTechLatest;

class Bike10
{
	final void run()
	{
		System.out.println("I am running");
	}
}

class Bike11 extends Bike10
{
	void run()
	{
		System.out.println("I am running safely");
	}
}


public class finalMethod {

	public static void main(String[] args) {
		Bike11 obj=new Bike11();
		obj.run();
		
		
		

	}

}
