package GroTechLatest;

interface print
{
	  public abstract  void print();
	public final static int x=4;
	
	
}

class A9 implements print
{
	public void print()
	{
		System.out.println("Print method implemented");
	}
}
public class InterfaceExamples {

	public static void main(String[] args) {
		
		
		//print obj=new print();
		
		print obj=new A9();
		obj.print();
		

	}

}
