package GroTechLatest;

public class ForLoopExample {

	public static void main(String[] args) {
		
		
		
		for(int i=1;i<5;i++)///i=1,1<5//i=2,2<5//i=3,3<5//i=4,4<5//i=5,5<5
		{
			System.out.println(i);//1//2//3//4
			//1++//2++//3++//4++
		}
		

	}

}
