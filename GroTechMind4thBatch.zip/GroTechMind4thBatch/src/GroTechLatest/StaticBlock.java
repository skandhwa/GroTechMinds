package GroTechLatest;

public class StaticBlock {
	
	static
	{
		 int x=5;
		int y=10+x;
		System.out.println(y);
		System.out.println("How are you");
	}

	public static void main(String[] args) {
		
		System.out.println("No I will not  execute first I am main");
	}

}
