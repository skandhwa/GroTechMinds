package GroTechLatest;

public class Bike {
	
	Bike()  ///creating a default constructor
	{
		System.out.println("Hello World");
	}
	

	public static void main(String[] args) {
		
		Bike obj=new Bike();
		
		

	}

}
