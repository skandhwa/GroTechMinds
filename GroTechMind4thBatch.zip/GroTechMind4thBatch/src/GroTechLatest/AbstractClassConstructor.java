package GroTechLatest;

abstract class Bike6
{
	 Bike6()
	{
		System.out.println("bike is created");
	}
	
	abstract int run(int x,int y);
	
	void changegear()
	{
		System.out.println("Gear Changed");
	}
	
	 static void test()
	 {
		 System.out.println("I am an static method");
	 }
	
	
}

class SubBike extends Bike6
{
	int run(int x,int y)
	{
		return x+y;
	}
}
public class AbstractClassConstructor {

	public static void main(String[] args) {
		
		//Bike6 obj=new Bike6;
		SubBike obj=new SubBike();
	obj.changegear();
	System.out.println(	obj.run(5, 6));
		//Bike6.test();
		SubBike.test();
		
		

	}

}
