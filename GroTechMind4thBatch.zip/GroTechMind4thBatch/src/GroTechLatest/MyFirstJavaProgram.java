//package GroTechLatest;
//
//class A
//{
//	 void display()
//	{
//		System.out.println("Hello World I am display method");
//		int x=10+20;
//		System.out.println(x);
//		int y=20-10;
//		System.out.println(y);		
//	}
//	
//	void display2()
//	{
//		System.out.println("Hello World I am display2 method");
//	}
//	
//}
//
//public class MyFirstJavaProgram {
//	
//	public static void main(String[] args) 
//	{
//		System.out.println("Hello World");
//		System.out.println("Hello New");
//		
//		A obj=new A();//new keyword is used at the time of object creation
////		obj.display();
//		A.display();
//		obj.display2();
//		
//		
//		//Inheritance
//		//Encapsuation
//		//polymorphism
//		//Abstraction
//		
//		
//		//compiler
//		//classloader
//		//interpretor 
//		//Memory areas
//		//JVM
//		
//
//	}
//
//}
