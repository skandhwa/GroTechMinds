package GroTechLatest;

import java.util.Scanner;

public class ScannerClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		 System.out.println("Enter first number");
		 
		 int a=sc.nextInt();
		 a=5;
		 
		 
		 System.out.println("Enter Second number");
		 int b=sc.nextInt();
		 
		 int c=a+b;
		 
		 System.out.println("the sum of two numbers are"+c);
		 
		 
		

	}

}
