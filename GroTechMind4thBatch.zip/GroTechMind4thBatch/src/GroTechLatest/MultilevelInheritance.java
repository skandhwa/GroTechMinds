package GroTechLatest;

class DU///Grand parent
{
	public static int subtraction(int x,int y,int z)
	{
		return x+y-z;
	}
}

class DI extends DU///parent
{
	void display()
	{
		System.out.println("Hey how are you");
	}
}

class GU extends DI
{
	void test()
	{
		System.out.println("I am test");
	}
}


public class MultilevelInheritance {

	public static void main(String[] args) {
		
		GU obj=new GU();
		System.out.println(	obj.subtraction(13, 34, 10));
		obj.display();
		obj.test();

	}

}
