package GroTechLatest;

class Bank
{
	int getrateofIntrest(int x,int y)
	{
		return x+y;
	}
}

class ICICI extends Bank
{
	int getrateofIntrest(int x,int y,int z)
	{
		return x+y+z;
	}
}

class YES extends Bank
{
	int getrateofIntrest(int x)
	{
		return x;
	}
}
class HDFC extends Bank
{
	int getrateofIntrest(int x,int y)
	{
		return x+y;
	}
}


public class MethodOverridingReal {

	public static void main(String[] args) {
		
		Bank obj=new Bank();
	System.out.println(obj.getrateofIntrest(3, 2));	
		
		ICICI obj1=new ICICI();
		System.out.println(	obj1.getrateofIntrest(4, 5, 8));
		//obj1.getrateofIntrest(5, 9);
		
		HDFC obj2=new HDFC();
		System.out.println(	obj2.getrateofIntrest(5, 9));
		
		YES obj3=new YES();
		System.out.println(	obj3.getrateofIntrest(7));
		
		
		

	}

}
