package GroTechLatest;

abstract class DB
{
	void display()///concrete method
	{
		System.out.println("Hello");
	}
	
	abstract int test(int x,int y);
}









abstract class CD extends DB
{
	 int test(int x,int y)
	{
		return x+y;
	}
	
	abstract void vehicle();
}

class GB extends CD
{
	void vehicle()
	{
		System.out.println("Hello How are you I m vehicle");
	}
}

public class AbstractClassDemo {

	public static void main(String[] args) {
		
		GB obj=new GB();
		obj.display();
		obj.test();
		obj.vehicle();

	}

}
