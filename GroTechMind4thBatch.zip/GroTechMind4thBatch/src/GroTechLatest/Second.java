package GroTechLatest;

public class Second {
	
	public void display()
	{
		System.out.println("hello");
	}
	

	public static void main(String[] args) {
		
		Second obj=new Second();
		obj.display();
		

	}

}
