package GroTechLatest;

abstract class Shape
{
	abstract void draw();
	
}

class Rectangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Rectangle");
	}
}

class Circle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Circle");
	}
}


public class AbstractClass2 {

	public static void main(String[] args) {
		
		Shape obj=new Circle();
		obj.draw();
		Rectangle obj1=new Rectangle();
		obj1.draw();
		

	}

}
