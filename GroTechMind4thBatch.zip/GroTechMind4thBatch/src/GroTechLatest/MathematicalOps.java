package GroTechLatest;

public class MathematicalOps {

	public static void main(String[] args) {
		 
//		int y=43;
//		int z=7;
//		
//		int t =y%z;  ///43%7 =1
//		
//		int f= y/z; ////43/7= 6
//		
//		
//		System.out.println(t);
//		System.out.println(f);
//		
		int a=  -785; ////5-1=4 		
		System.out.println(~a);
		
		
		int u=100;
		System.out.println(u<<3);  //100 * 2^3= 100*8=800

		double t=27;
		double g= 27 / 5;
		System.out.println(g);
		
		
		
	}

}
