package GroTechLatest;

public class DefaultAnotherclass {

	public static void main(String[] args) {
		
		GA obj=new GA();
		obj.display();
		
		

	}

}
