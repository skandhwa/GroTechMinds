package GroTechLatest;

class Bike9
{
	final int speed=90;
	final float pi=3.145f;
	final float g=9.83f;
	
	void run()
	{
		speed=900;
	}
	
}


public class FinalvariableExample {
	

	public static void main(String[] args) {
		Bike9 obj=new Bike9();
		obj.run();

	}

}
