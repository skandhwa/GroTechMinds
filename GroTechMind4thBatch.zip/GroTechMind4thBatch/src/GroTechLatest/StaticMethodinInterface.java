package GroTechLatest;

interface Drawable12
{
	void draw();
	static int cube(int x)
	{
		return x*x*x;
	}
}

class Rectangle12 implements Drawable12
{

	@Override
	public void draw() {
		System.out.println("Rectangle");
		
	}
	
}
public class StaticMethodinInterface {

	public static void main(String[] args) {
		Drawable12 ref=new Rectangle12();
		ref.draw();
	System.out.println(	Drawable12.cube(5));
	}

}
