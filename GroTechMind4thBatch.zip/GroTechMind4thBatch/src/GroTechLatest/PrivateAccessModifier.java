package GroTechLatest;


 class SimpleNew
{
	private int d=40;
	private void test()
	{
		System.out.println("Hello");
	}
}
 
 class Simple2 extends SimpleNew
 {
	 
 }
 

public class PrivateAccessModifier {
	
	

	public static void main(String[] args) {
		
		SimpleNew obj=new SimpleNew();
		obj.test();
		
		

	}

}
