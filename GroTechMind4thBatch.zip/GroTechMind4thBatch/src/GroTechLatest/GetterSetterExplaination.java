package GroTechLatest;

public class GetterSetterExplaination {

	public static void main(String[] args) {
		
		
		Student7 obj=new Student7();
		obj.setName("Saurabh");
	System.out.println(	obj.getName());

	}

}
