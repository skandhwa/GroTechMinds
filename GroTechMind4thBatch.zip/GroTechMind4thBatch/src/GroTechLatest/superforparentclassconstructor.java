package GroTechLatest;

class DT
{
	int abc;
	int bdf;
	DT(int a,int b)
	{
	    abc=a;
	    bdf=b;
	    
	}
}
class ET extends DT
{
     ET()
     {
    	 super();
    	 System.out.println("I am child class");
    	 
     }
     
    }
public class superforparentclassconstructor {

	public static void main(String[] args) {
		
		ET obj=new ET();

	}

}
