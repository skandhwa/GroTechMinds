package GroTechLatest;

interface drawable
{
	void draw();
	
}

class Rectangle7 implements drawable
{
	public void draw()
	{
		System.out.println("I am rectangle");
	}
}

class Circle7 implements drawable
{
	public void draw()
	{
		System.out.println("I am Circle");
	}
}




public class RealExampleofINTERFACE {

	public static void main(String[] args) {
	
		drawable obj=new Circle7();
		obj.draw();
//		drawable obj1=new Rectangle7();
//		obj.draw();
		
		Rectangle7 obj1=new Rectangle7();
		obj1.draw();
		
		//WebDriver driver=new ChromeDriver();

	}

}
