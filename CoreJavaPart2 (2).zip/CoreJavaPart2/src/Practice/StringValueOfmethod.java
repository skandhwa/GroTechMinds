package Practice;

public class StringValueOfmethod {

	public static void main(String[] args) {
		
		int x=10;
		String s1=String.valueOf(x);
		System.out.println(s1);
		
		System.out.println(s1 + " is of type " + ((Object)s1).getClass()); 
	
		
		
		
		
		
		
		
		
		
		
		
		
//		int x=10;
//		String str1;
//		
//		boolean bol=true;
//		String str2=
//		
//		
//		str1=String.valueOf(x);
//		System.out.println(str1);
//		
//		 System.out.println(str1 + " is of type " + ((Object)str1).getClass().getSimpleName()); 

	}

}
