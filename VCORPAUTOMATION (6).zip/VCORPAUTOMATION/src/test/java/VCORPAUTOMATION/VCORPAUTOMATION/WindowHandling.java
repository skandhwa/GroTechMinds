package VCORPAUTOMATION.VCORPAUTOMATION;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowHandling {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://demo.automationtesting.in/Windows.html");
		Thread.sleep(3000);
		
		//driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
		
		
	String WindowID=	driver.getWindowHandle();
	System.out.println(WindowID);
		
		
		driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
		Thread.sleep(3000);
	Set <String> S1=	driver.getWindowHandles();
	System.out.println(S1);
	
	Iterator <String> I1=S1.iterator();
	while(I1.hasNext())////
	{
		String childwindow=I1.next();///
		if(!WindowID.equals(childwindow))
		{
			driver.switchTo().window(childwindow);
		String title=	driver.switchTo().window(childwindow).getTitle();
		System.out.println(title);
		driver.close();
		}
		
		
	}
	
	driver.switchTo().window(WindowID);
	
	
	driver.navigate().refresh();
	
	driver.findElement(By.xpath("//a[@href='#Seperate']")).click();
	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	
	Set <String> S2=	driver.getWindowHandles();
	System.out.println(S2);
	
	Iterator <String> I2=S2.iterator();
	while(I1.hasNext())////
	{
		String childwindow2=I2.next();///
		if(!WindowID.equals(childwindow2))
		{
			driver.switchTo().window(childwindow2);
		String title2=	driver.switchTo().window(childwindow2).getTitle();
		System.out.println(title2);
		driver.close();
		}
		
		
	}
	
	driver.switchTo().window(WindowID);
	
	
	
	
	
	
	
	
	
	
	
	}
	
}
	
	
	


