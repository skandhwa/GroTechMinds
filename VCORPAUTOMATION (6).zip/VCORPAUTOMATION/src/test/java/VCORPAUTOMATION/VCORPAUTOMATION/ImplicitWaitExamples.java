package VCORPAUTOMATION.VCORPAUTOMATION;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ImplicitWaitExamples {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		WebElement State=new WebDriverWait(driver,Duration.ofSeconds(5))
				.until(ExpectedConditions.
						elementToBeClickable(By.xpath("(//span[@class='select2-selection select2-selection--single'])[1]")));
		
		State.click();
		
		
		Wait<WebDriver> wait=new FluentWait<WebDriver>(driver).
				withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(5)).
				ignoring(NoSuchElementException.class);
		
		
		
		
		

	}

}
