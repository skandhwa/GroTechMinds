package VCORPAUTOMATION.VCORPAUTOMATION;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DynamicWebTables {

	public static void main(String[] args) {
		
		////FIRST WAY OF DYNAMIC WEB TABLE
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://testuserautomation.github.io/WebTable/");
		
	String Before_Xpath=	"//table/tbody/tr[";
	
	String After_Xpath= "]/td[2]";
	
List rowsize=	driver.findElements(By.xpath("//table/tbody/tr"));
int x=rowsize.size();


   for(int i=2;i<x;i++)
   {
	String name=  driver.findElement(By.xpath(Before_Xpath+i+After_Xpath)).getText();
	System.out.println(name);
	
	
	if(name.contains("Ammy"))
	{
		driver.findElement(By.xpath("//tbody/tr [" + i + "]/td[1]/input")).click();
		System.out.println("Candidate is Selected");
		break;
	}
	
	
    }
   
   driver.navigate().refresh();
   
   ///SECOND METHOD
   
   driver.findElement(By.xpath("//td[contains(text(),'Jessica')]//preceding-sibling::td//input[@type='checkbox']")).click();
   
   
   
	
	
	
		

	}

}
