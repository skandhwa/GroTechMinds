package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FIRSTWebElementCommand {

	public static void main(String[] args) throws InterruptedException {
		
		
		try
		{
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		
		
		
		
		
		driver.findElement(By.xpath("//input[@id='vfb-5']")).sendKeys("Saurabh Java");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='vfb-5']")).clear();
		WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-31678-1']"));
		
		if(ele.isDisplayed()==true)
		{
			ele.click();
		}
		else
		{
			System.out.println("Element is not visible");
		}
		
		}
		
		catch(Exception e )
		{
			System.out.println("caught with" +e);
		}
	
		
		
		

	}

}
