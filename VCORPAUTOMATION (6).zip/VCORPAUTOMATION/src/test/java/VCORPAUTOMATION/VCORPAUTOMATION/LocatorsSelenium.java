package VCORPAUTOMATION.VCORPAUTOMATION;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LocatorsSelenium {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		
		List<WebElement> li=driver.findElements(By.tagName("input"));
		int y=li.size();
		System.out.println(y);
		
		List<WebElement> li2=driver.findElements(By.tagName("a"));
		int x=li2.size();
		System.out.println(x);
		
		//driver.findElement(By.id("vfb-5")).sendKeys("Saurabh");
		//driver.findElement(By.name("vfb-5")).sendKeys("Kuamar");
		//driver.findElement(By.className("vfb-text  vfb-medium  required  ")).sendKeys("TestNew");
		
		
		
		

	}

}
