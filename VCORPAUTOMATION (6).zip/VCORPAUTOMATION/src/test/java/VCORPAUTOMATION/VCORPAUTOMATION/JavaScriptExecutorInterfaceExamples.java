package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JavaScriptExecutorInterfaceExamples {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm");
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		//js.executeScript("document.getElementByXpath('//input[@name='firstname']').value='Saurabh';");
		
		WebElement firstname=driver.findElement(By.xpath("//input[@name='firstname']"));
		js.executeScript("arguments[0].value='Saurabh';",firstname);

	}

}
