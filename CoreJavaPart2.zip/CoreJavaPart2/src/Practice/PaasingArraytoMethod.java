package Practice;

class TestArray2
{
	static void min(int a[])///6,2,1,4
	{
		int min=a[0];///min=6
		for(int i=1;i<a.length;i++)//i=1,i<4=1<4//i=2,2<4//i=3,3<4
		{
			if(min>a[i])//6>a[1]//6>2//2>a[2]//2>1///1>4
			{
				min=a[i];///min=a[1]=2///min=a[2]=1
			}
		}
		
		System.out.println(min);
	}
	
	
	
}
public class PaasingArraytoMethod {

	public static void main(String[] args) {
		
		int a[]= {6,2,1,4};
		TestArray2.min(a);
		
		

	}

}
