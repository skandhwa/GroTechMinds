package Practice;

public class SumaoAllArrayElements {

	public static void main(String[] args) {
		
		
		int a[]= {64,32,12,41,28};
		int sum=0;
		
		for(int i=0;i<a.length;i++)//i=0,0<5///i=1,1<5//i=2,2<5
		{
			sum=sum+a[i];///sum=0+64=64///sum=64+32=96////sum=96+12//
		}
		
		System.out.println(sum);
		

	}

}
