package Practice;

import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		
		Vector<Integer> v=new Vector<>();
		v.add(12);
		v.add(34);
		v.add(46);
		
		System.out.println(v);
		
	System.out.println(v.clone());
		
		
		

	}

}
