package Practice;

import java.util.ArrayList;

public class ArrayListExample2 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		
		li.add("Mango");
		li.add("Orange");
		li.add("Pineapple");
		li.add(2,"Strawberry");
		li.add(5,"Grapeds");
	
		li.add("cherry");
		li.add("guava");
		li.add(3,"Kiwi");
		li.add(4,"Pomegranate");
		li.add("Apple");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		

	}

}
