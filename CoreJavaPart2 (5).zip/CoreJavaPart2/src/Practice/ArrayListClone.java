package Practice;

import java.util.ArrayList;

public class ArrayListClone {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
     	li.add(4);
		li.add(56);
		li.add(49);
		li.add(5689);
		li.add(999);
		li.add(1999);
		li.add(399);
		li.add(1499);				
		System.out.println(li);
		
		
		////CLONING AN ARRAY LIST 
		
//		ArrayList<Integer> abcd= (ArrayList<Integer>)li.clone();
//		System.out.println(abcd);
		
		///RETAIN ALL METHOD
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
     	li2.add(4);
		li2.add(56);
		li2.add(492);
		li2.add(569);
		li2.add(1099);
		li2.add(399);
		
		System.out.println(li2);
		
		li.retainAll(li2);
		
		System.out.println(li);
		
		
	}

}
