package Practice;

public class throwKeywordExample {
	
	public static void validate(int age) throws ArithmeticException
	{
		if(age<18)
		{
			throw new ArithmeticException("You are not elligible to vote");
			
			
		}
		
		
		
		else
		{
			System.out.println("You are elligible");
		}
	}
	
	
	

	public static void main(String[] args) {
		
		validate(23);
		System.out.println("rest of code");
		int x=10;
		int y=x/2;
		System.out.println(y);
		
		
		

	}

}
