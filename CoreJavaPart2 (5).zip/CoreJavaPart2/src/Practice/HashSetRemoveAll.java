package Practice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HashSetRemoveAll {

	public static void main(String[] args) {
		
		Set<Integer> S1=new HashSet<Integer>();
		S1.add(45);
		S1.add(67);
		S1.add(15);
		S1.add(17);
		S1.add(25);
		S1.add(47);
		S1.add(25);
		S1.add(47);
		System.out.println("Elements of Set before");
		System.out.println();
		for(int y:S1)
		{
			System.out.println(y);
		}
		
		int p=S1.size();
		System.out.println("The size of Set is  "+p);
		
		
		System.out.println("Elements of ArrayList before");
		System.out.println();
		ArrayList<Integer> A=new ArrayList<Integer>();
		A.add(45);
		A.add(17);
		A.add(76);
		A.add(25);
		for(int t:A)
		{
			System.out.println(t);
		}
		
		
		System.out.println();
		System.out.println();
		
		////////REMOVE ALL METHOD
		
//		S1.removeAll(A);
//		
//		for(int z:S1)
//		{
//			System.out.println(z);
//		}
		
		
S1.retainAll(A);
		
		for(int z:S1)
		{
			System.out.println(z);
		}

	}

}
