package Practice;

import java.util.*;
import java.util.Collections;

public class MinimumElementFromArrayList {

	public static void main(String[] args) {
		
ArrayList<Integer> li=new ArrayList<Integer>();
	
		li.add(104);
		li.add(56);
		li.add(29);
		li.add(139);
		li.add(419);
		li.add(749);
		
	int x=	Collections.min(li);
	System.out.println(x);
	
	int y=	Collections.max(li);
	System.out.println(y);
		

	}

}
