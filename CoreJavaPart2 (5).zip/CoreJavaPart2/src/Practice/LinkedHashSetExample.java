package Practice;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetExample {

	public static void main(String[] args) {
		
		LinkedHashSet<String> S=new LinkedHashSet<String>();
		
	//HashSet<String> S=new HashSet<String>();
		S.add("Mango");
		S.add("Guava");
		S.add("Pitch");
		S.add("Orange");
		S.add("kiwi");
		//S.add(null);
		Iterator<String> itr=S.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		

	}

}
