package Practice;

import java.util.HashSet;
import java.util.Set;

public class SetExample {

	public static void main(String[] args) {
		
		Set<Integer> S=new HashSet<Integer>();
		S.add(12);
		S.add(23);
		S.add(45);
		S.add(12);
		S.add(6);
		S.add(67);
		S.add(0);
		S.add(0);
		
		
		for(int x:S)
		{
			System.out.println(x);
		}
		
		System.out.println("------------THIS IS SET OF STRING--------------");
		System.out.println();
		System.out.println();
		Set<String> S1=new HashSet<String>();
		S1.add("Mango");
		S1.add("Banana");
		S1.add("Apple");
		S1.add("Kiwi");
		S1.add(null);
		S1.add(null);
		S1.add("Mango");
		
		
		for(String y:S1)
		{
			System.out.println(y);
		}
		
		
		
		
		

	}

}
