package Practice;

public class ArrayCopyMethod {

	public static void main(String[] args) {
		int a[]= {12,67,89,95};
		 int []b=new int [a.length];
		 
		 for(int i=0;i<a.length;i++)///i=0,i<4//i=1,1<4//4<4
		 {
			 b[i]=a[i];//b[0]=a[0]=12///b[1]=a[1]=67
			 System.out.println(b[i]);
		 }

	}

}