package Practice;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		
		TreeSet<String> S=new TreeSet<String>();
		
		S.add("Mango");
		S.add("Guava");
		S.add("Pitch");
		S.add("Orange");
		S.add("Kiwi");
		
		////FOR ASCENDING ORDER
		
//		Iterator<String> itr=S.iterator();
//		
//		while(itr.hasNext())
//		{
//			System.out.println(itr.next());
//		}
		
		
	////FOR DESCENDING ORDER
		Iterator<String> itr=S.descendingIterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		System.out.println("Tree Set Specific Methods");
		
		System.out.println();
		System.out.println();
		
	System.out.println(S.pollFirst());
	
	System.out.println	(S.pollLast());
		
		
		
		
		
		
		
		
	}

}
