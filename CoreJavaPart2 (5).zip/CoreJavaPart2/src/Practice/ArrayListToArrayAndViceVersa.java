package Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListToArrayAndViceVersa {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<>();
		//List<Integer> li2=new ArrayList<>();
		
		
		li.add("Mango");
		li.add("Orange");
		li.add("Pineapple");
		li.add("Strawberry");
		//li2.add(56);
		
		
		int x=li.size();
		
		System.out.println(li);
		System.out.println();
		System.out.println();
		
		System.out.println("----------CONVERTING ARRAYLIST TO ARRAY------------");
		System.out.println();
		System.out.println();
		
		
		String[] li2= li.toArray(new String[x]);
		
		////int []a=new int[400];
		
		for(String y:li2)
		{
			System.out.println(y);
		}
		
		System.out.println();
		System.out.println();
		
		System.out.println("----------CONVERTING ARRAY TO ARRAYLIST------------");
		System.out.println();
		System.out.println();
		
		List<String> li3=new ArrayList<>();
		
		//List<WebElement> li=new List<>();
		
		li3=Arrays.asList(li2);
		
		for(String z:li3)
		{
			System.out.println(z);
		}
		
		
		
		
		
		
		

	}

}
