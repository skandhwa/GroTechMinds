package Practice;

import java.util.ArrayList;

public class ArrayListAddAllMethod {

	public static void main(String[] args) {
		
		
ArrayList<Integer> li=new ArrayList<Integer>();
     	li.add(4);
		li.add(56);
		li.add(49);
		li.add(56);
		li.add(999);
		li.add(56);
		li.add(49);
		System.out.println(li.get(3));	
		
		li.set(4, 789);
		
		System.out.println(li);
		
		
ArrayList<Integer> li2=new ArrayList<Integer>();
	
		li2.add(41);//0
		li2.add(562);//1
		li2.add(699);//2
		li2.add(562);//3
		li2.add(419);
		li2.add(562);
		li2.add(419);
		li2.add(562);
		li2.add(419);
		
	int x=	li2.size();
	

		
	System.out.println(x);	
	
	System.out.println(li2);
	li2.remove(2);
	System.out.println(li2);	
	
	li2.clear();
	
	System.out.println(li2);
		
		
		
	System.out.println(li2.addAll(li));	
	
	System.out.println(li2);
	
	li2.clear();
	
	System.out.println(li2);
		
		
		
	}
	
	
	
	
	
	
	
	
	

}
