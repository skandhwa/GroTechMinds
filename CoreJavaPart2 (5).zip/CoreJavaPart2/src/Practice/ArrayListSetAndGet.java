package Practice;

import java.util.ArrayList;

public class ArrayListSetAndGet {

	public static void main(String[] args) {
		
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Mango");//0
		li.add("Orange");//1
		li.add("Pineapple");//2
		li.add("Strawberry");//3
		li.add("Grapes");//4
		
		li.set(3, "Guava");
		String val=li.get(4);
		System.out.println(val);
		
		
		System.out.println(li);
		
	boolean flag=	li.contains("Kiwi");
	System.out.println(flag);
		
		

	}

}
