package Practice;

import java.util.TreeSet;

public class TreeSetSecondExample {

	public static void main(String[] args) {
		
		
TreeSet<String> S=new TreeSet<String>();
		
		S.add("A");
		S.add("B");
		S.add("C");
		S.add("D");
		S.add("E");
		
	
		
		System.out.println(S);
		
		System.out.println(S.descendingSet());
		
		System.out.println("Head Set");
		System.out.println(S.headSet("D",true));
		
		System.out.println("Tail Set");
		System.out.println(S.tailSet("D",false));
		
		
		System.out.println("Sub Set");
		System.out.println(S.subSet("A", "E"));
		
		
		System.out.println(S.subSet("A",false, "E",true));
		
		
		
		
		
		
		
		

	}

}
