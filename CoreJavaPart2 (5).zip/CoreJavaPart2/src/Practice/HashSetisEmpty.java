package Practice;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetisEmpty {

	public static void main(String[] args) {
		
		
		Set<String> S1=new HashSet<String>();
		
		boolean flag=S1.isEmpty();
		System.out.println(flag);
		
		
		S1.add("Mango");
		S1.add("Banana");
		S1.add("Apple");
		S1.add("Kiwi");
		S1.add(null);
		
		boolean flag2=S1.isEmpty();
		System.out.println(flag2);
		
		Iterator itr=S1.iterator();
		
		while(itr.hasNext())
		{
		System.out.println(itr.next());	
		}
		
		
		
		
		
		
		

	}

}
