package Practice;

import java.util.Iterator;
import java.util.Stack;

public class StackWithString {

	public static void main(String[] args) {
		
		Stack<String> stk=new Stack<>();
		stk.push("Macbok");
		stk.push("HP");
		stk.push("Dell");
		stk.push("Compaq");
		stk.push("Asus");
		
	int x=	stk.search("Asus");
	System.out.println(x);
	
	int z=stk.size();
	System.out.println(z);
	
	Iterator itr=stk.iterator();
	
	while(itr.hasNext())
	{
	System.out.println(itr.next());	
	}
	
	stk.pop();
	String Laptop=stk.peek();
	System.out.println("The top value is  "+Laptop);
	
	

	}

}
