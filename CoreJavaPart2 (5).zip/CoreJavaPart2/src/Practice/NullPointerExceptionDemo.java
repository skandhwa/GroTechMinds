package Practice;

public class NullPointerExceptionDemo {

	public static void main(String[] args) {
		
		try
		{
			
			
			int []a=new int[4];
			
			a[0]=1;
			a[1]=2;
			a[2]=4;
			a[3]=7;
			
			a[4]=11;
			
			for(int x:a)
			{
				System.out.println(x);
			}
		String str=null;
		int l=str.length();
		System.out.println(l);
		
		
		
 
		
		int p=10/0;
		System.out.println(p);
		
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		
		catch(NullPointerException f)
		{
			System.out.println(f);
		}
		
		
		catch(ArithmeticException g)
		{
			System.out.println(g);
		}
		
		
		int d=20;
		int b=30;
		int c=d+b;
		System.out.println("The value of C is  "+c);
		

	}

}
