package Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadDataFromAFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File f=new File("D:\\File Demo\\New4.txt");
		Scanner sc=new Scanner(f);
		
		while(sc.hasNextLine())
		{
			String S=sc.nextLine();
			
			System.out.println(S);
			
			
		}
		
		sc.close();
		
		

	}

}
