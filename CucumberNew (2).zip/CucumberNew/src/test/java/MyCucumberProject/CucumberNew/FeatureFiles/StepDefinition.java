package MyCucumberProject.CucumberNew.FeatureFiles;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	@Before
	public void test()
	{
		
	}
	
	
	@Before("@first")
	public void beforetestsuite()
	{
		
	}
	
	@After("@second")
	public void closeconnectionafterscenario()
	{
		
	}
	@After("first")
	public void closeconnectionafterscenario1()
	{
		
	}
	
	
	
	@Before("@second")
	@Given("User opens the facebook URL in the browser")
	public void user_opens_the_facebook_url_in_the_browser() {
		
		System.out.println("I am feature 2");
	    
	}

	@Given("User enters the user id in the userid field")
	public void user_enters_the_user_id_in_the_userid_field() {
		
		System.out.println("I am feature 3");
	    
	}

	@Given("User enters the password in the password field")
	public void user_enters_the_password_in_the_password_field() {
		System.out.println("I am feature 4");
	}

	@When("User clicks on login button")
	public void user_clicks_on_login_button() {
		System.out.println("I am feature 5");
	    
	}

	@Then("User will be navigated to facebook home page")
	public void user_will_be_navigated_to_facebook_home_page() {
	    
	}

	@Given("User enters the skan1234 in the userid field")
	public void user_enters_the_skan1234_in_the_userid_field() {
	   
	}

	@Given("User enters the test@{int} in the password field")
	public void user_enters_the_test_in_the_password_field(Integer int1) {
	    
	}
	
	@Then("User verifies the title")
	public void user_verifies_the_title() {
	    
	}

	
	
	

}
