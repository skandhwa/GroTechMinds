package stepDefinitions;

import Pagefactory.LoginPage;
import Utilities.DriverInitialization;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends DriverInitialization {
	
	//LoginPage obj=new LoginPage(DriverInitialization.getDriver());
	
	
	LoginPage obj=new LoginPage(DriverInitialization.getDriver());
	
	
	
	@Given("User Open the URL for Orange HRM")
	public void user_open_the_url_for_orange_hrm() throws InterruptedException {
		Thread.sleep(5000);
	   System.out.println("Orange HRM page is opened");
	}

	@Then("User Enters the {string}")
	public void user_enters_the(String username) {
		
		obj.enterUsername(username);
	    
	}

	@Then("the the User Enters the {string}")
	public void the_the_user_enters_the(String password) {
		
		obj.enterPassword(password);
	   
	}

	@When("User Clicks on Login Button")
	public void user_clicks_on_login_button() {
		
		obj.clickSubmit();
	   
	}

	@Then("User will be navigated to Orange Hrm Home page")
	public void user_will_be_navigated_to_orange_hrm_home_page() {
		
		
	    
	}


	
	
	

}
