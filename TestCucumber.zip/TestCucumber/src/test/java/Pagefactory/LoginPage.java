package Pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	public LoginPage(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//input[@name='username']")
	WebElement username;
	
	@FindBy(xpath="//input[@name='password']")
	WebElement password;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement login;
	
	
	public void enterUsername(String text1)
	{
		username.sendKeys(text1);
	}
	
	public void enterPassword(String text2)
	{
		password.sendKeys(text2);
	}
	
	public void clickSubmit()
	{
		login.click();
	}
	
	

	
	
	
	
	
	
	

}
