package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class BaseClass {
	
	static WebDriver driver;
	
	public static  WebDriver  InitializeDriver() 
	{
		 
		 driver=new ChromeDriver();
		
		 WebDriverManager.chromedriver().setup();
		   
		   driver.manage().window().maximize();
		  
			try {
				driver.get(GetDataFromExcel.getURL());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return driver;
	}
	
	public  void takescreenshot() throws IOException
	{
		
		TakesScreenshot Srcshot=(TakesScreenshot)(driver);
		File SrcFile=Srcshot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File("E:\\TakeScreenShot\\Test3.jpg");
		try {
			FileUtils.copyFile(SrcFile, DestFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	
	public void ScrollDown()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
	}
	
	

	
	
	
	
  
	
	

}
