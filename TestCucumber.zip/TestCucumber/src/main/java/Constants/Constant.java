package Constants;

public class Constant {
	
	public static final String TESTDATAPATH="C:\\Users\\saura\\OneDrive\\Documents\\TestData2607.xlsx";
	

}
