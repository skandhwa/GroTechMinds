/**
 * 
 */
/**
 * @author saura
 *
 */
module CoreJavaPart2 {
}