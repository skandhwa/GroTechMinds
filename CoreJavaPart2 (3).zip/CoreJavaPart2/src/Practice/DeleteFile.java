package Practice;

import java.io.File;

public class DeleteFile {

	public static void main(String[] args) {
		
		File f=new File("D:\\File Demo\\New3.txt");
	boolean flag=	f.delete();
	
	if(flag==true)
	{
		System.out.println(f.getName());
		System.out.println(f.getAbsolutePath());
	}
		

	}

}
