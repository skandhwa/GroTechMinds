package Practice;

public class ArrayCloning {

	public static void main(String[] args) {
		 int a[]= {33,4,5,7};
		 
		 for(int x:a)
		 {
			 System.out.print(x+" ");
		 }
		 
		 int c[]=a.clone();
		 
		 System.out.println();
		 System.out.println("---------I AM CLONING AN ARRAY-----------");
		 
		 for(int y:c)
		 {
			 System.out.print(y+" ");
		 }
		 
		 System.out.println();
		 System.out.println("Are both the arrays equal");
			  System.out.println(a==c);
		 

	}

}
