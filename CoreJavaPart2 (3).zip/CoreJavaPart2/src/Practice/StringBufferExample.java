package Practice;

public class StringBufferExample {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Hello");
		System.out.println(sb);
		sb.append("java");
		System.out.println(sb);
		

	}

}
 