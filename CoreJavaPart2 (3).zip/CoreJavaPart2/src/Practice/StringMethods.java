package Practice;

public class StringMethods {

	public static void main(String[] args) {
		
		String str="Saurabh";
	String str1=	str.concat("Trainer");///saurabhtrainer
		System.out.println(str1);
		
		char ch2=str1.charAt(5);
		
		System.out.println(ch2);
	
		////REPLACE METHOD
		
		String str3="Java";
		
		String str4=str3.replace('a','c');
		System.out.println(str4);
		
		///String Length
		
		int l=str3.length();
		System.out.println(l);
		

	}

}
