package Practice;

public class StringSplitMethod {

	public static void main(String[] args) {
		
		String str="Hello All I am learning E-Commerce";
		
	String[] words=	str.split(" ");//
	
System.out.println(words[3]);	
	
	
	

	}

}
