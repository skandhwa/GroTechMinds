package Practice;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowSecondExample {
	
	public static void method() throws FileNotFoundException
	{
		FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\Maven SetUP.txt");
		BufferedReader br=new BufferedReader(f);
		
		throw new FileNotFoundException();
		
	}
	
		public static void main(String[] args) {
			
			try
			{
				method();
			}
			
			catch(Exception e)
			{
				System.out.println(e);
			}
		
		int x=10;
		int y=20;
		int z=x+y;
		
		System.out.println(z);
		

	}

}
