package Practice;

public class ArrayFurtherDeclarationandExamples {

	public static void main(String[] args) {
		
		int c[]= {76,54,87,90,21};
		
		System.out.println(c);
		
		for(int x:c)//X:76
		{
			System.out.println(x);
		}
		

	}

}
