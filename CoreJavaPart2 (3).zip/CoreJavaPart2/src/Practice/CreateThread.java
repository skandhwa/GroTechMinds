package Practice;

public class CreateThread extends Thread {////By extending thread class

	public void run()
	{
		System.out.println("Thread is running");
	}
	
	
	public static void main(String[] args) {
		
		
		CreateThread obj=new CreateThread();
		obj.start();

	}

}
