package Practice;

public class ArrayIndexOutOfBounds {

	public static void main(String[] args) {
		
		int a[]= {23,45,67,14};
		System.out.println(a[4]);
		
	}

}
