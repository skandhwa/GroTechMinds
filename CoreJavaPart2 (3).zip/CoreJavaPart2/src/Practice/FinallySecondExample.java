package Practice;

public class FinallySecondExample {

	public static void main(String[] args) {
              
		finally
		{
		
             int x=20/0;
             System.out.println(x);
             
		}
             
           

	}

}
