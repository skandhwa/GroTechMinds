package Practice;

public class AddTwoMatrix {

	public static void main(String[] args) {
		
		int a[][]= {{1,3,4},{3,4,5}};
		int b[][]= {{1,3,4},{3,4,5}};
		
		int d[][]=b.clone();
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				
				System.out.print(d[i][j]+" ");
			}
			System.out.println();
		}
		
		
		
		int c[][]=new int[2][3];
		
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				c[i][j]=a[i][j]+b[i][j];//c[0][0]=a[0][0]+b[0][0]
				System.out.print(c[i][j]+" ");
			}
			System.out.println();
		}
		
		
	}

}
