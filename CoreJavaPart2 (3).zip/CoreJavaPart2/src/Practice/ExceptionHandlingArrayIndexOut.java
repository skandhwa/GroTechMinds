package Practice;

public class ExceptionHandlingArrayIndexOut {

	public static void main(String[] args) {
		
		try
		{
		
		int []a=new int[4];
		
		a[0]=1;
		a[1]=2;
		a[2]=4;
		a[3]=7;
		
		a[4]=11;
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		
		
		int d=20;
		int b=30;
		int c=d+b;
		System.out.println("The value of C is  "+c);
		

	}

}
