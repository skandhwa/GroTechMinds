package Practice;

public class IndexofStringMethod {

	public static void main(String[] args) {
		String str="          Saurabh Java          t";
		System.out.println(str);
		
		String str2=str.replaceAll("  ","");
		System.out.println(str2);
		
	String str1=	str.trim();
		System.out.println(str1);
		
		
		double index=str.indexOf("a");
		System.out.println(index);
		

	}

}
