package Practice;

import java.io.File;
import java.io.IOException;

public class CreateAFile {

	public static void main(String[] args) {
		
		
		File f=new File("D:\\File Demo\\abc5.png");
		boolean flag=f.createNewFile();
		System.out.println(flag);
		
		
	System.out.println(f.getName());	
		
		
		}
		
		
		

	}


