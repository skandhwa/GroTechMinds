package Practice;

public class StringFirstExample {

	public static void main(String[] args) {
		
		
//		char []ch= {'S','a','u','r'};
//		
//		int []a= {3,4,5,6,7};
//		
//		String S=new String(ch);
//		System.out.println(S);
		
		
		//1. String Literal
		
		String Str1="Welcome";
		
		//Using New Keyword
		char []ch= {'S','a','u','r'};
		String S=new String(ch);
		
		System.out.println(S);
		System.out.println(Str1);
		
		

	}

}
