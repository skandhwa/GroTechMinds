package Practice;

import java.util.Arrays;

public class ArrayCompareMethod {

	public static void main(String[] args) {
		
		
		int[]a= {9,7,8,1,2,9};
		int[]b= {9,7,8,1,2,19};
		
	int x=	Arrays.compare(b,a);
	
	System.out.println(x);

	}

}
