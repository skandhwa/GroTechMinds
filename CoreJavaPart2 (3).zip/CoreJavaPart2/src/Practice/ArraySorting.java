package Practice;

public class ArraySorting {

	public static void main(String[] args) {
		int a[]= {64,32,12,41,28};
		
		for(int i=0;i<a.length;i++)///i=0,0<5
		{
			
			for (int j=i+1;j<a.length;j++)//j=0+1=1,1<5//j=2
			{
				
				if(a[i]>a[j])///a[0]>a[1]//a[0]>a[2]
				{
					int t=a[i];///t=64
					a[i]=a[j];//a[0]=a[1]//32
					a[j]=t;//a[1]=64
				}
				
				//12 64 32 41 28
			}
			
			
			
		}
		
		for(int k=0;k<a.length;k++)
		{
			System.out.println(a[k]);
		}

	}

}
