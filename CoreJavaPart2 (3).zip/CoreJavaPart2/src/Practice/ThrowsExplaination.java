package Practice;

import java.io.IOException;

public class ThrowsExplaination {
	
	void m() throws IOException 
	{
		throw new IOException("There is an error in device");
	}
	
	
	void n() 
	{
		try {
			m();
		
		}
		
		finally
		{
			
		}
	}
	
	void p()
	{
		try {
			n();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ThrowsExplaination obj=new ThrowsExplaination();
		obj.p();
		
		

	}

}
