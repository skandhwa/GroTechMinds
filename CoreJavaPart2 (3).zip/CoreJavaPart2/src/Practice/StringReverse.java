package Practice;

public class StringReverse {

	public static void main(String[] args) {
		
          String str="MALAYALAM";
          
          String Reversedstr="";
          
          for(int i=str.length()-1;i>=0;--i)///i=3,3>0//i=2,2>0//i=1,1>=0//0>=0
          {
        	  Reversedstr=Reversedstr+ str.charAt(i);///null+a=a//a+v//av+a=ava//ava+j=avaj
          }
          
          System.out.println(Reversedstr);///avaj
          
          
          if(str.equalsIgnoreCase(Reversedstr))
          {
        	  System.out.println("Palindrome");
          }
          else
        	  System.out.println("Not Palindrome");
	}

}
