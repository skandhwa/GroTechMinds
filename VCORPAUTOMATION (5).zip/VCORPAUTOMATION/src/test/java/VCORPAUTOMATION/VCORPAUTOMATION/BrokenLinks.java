package VCORPAUTOMATION.VCORPAUTOMATION;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrokenLinks {

	public static void main(String[] args) throws MalformedURLException, IOException {
		
		//String homepage="https://www.zlti.com/";
		String URL="";
		HttpURLConnection huc=null;
		int responsecode=200;
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.zlti.com/");
		List<WebElement> li=driver.findElements(By.tagName("a"));
		Iterator<WebElement> itr=li.iterator();
		while(itr.hasNext())
		{
			URL=itr.next().getAttribute("href");
			System.out.println(URL);
			if(URL==null || URL.isEmpty())
			{
				System.out.println("URL is not configured");
				continue;
			}
			
			
			huc=(HttpURLConnection)(new URL(URL).openConnection());
			huc.connect();
			responsecode=huc.getResponseCode();
			if(responsecode>=400)
			{
				System.out.println("Broken Link");
			}
			else
				System.out.println("Not a Broken Link");
			
			try
			{
				System.out.println("Hello");
			}
			catch(NoSuchWindowException e)
			{
				System.out.println(e);
			}
			
			
			driver.findElement(By.name("q")).sendKeys("cheese" + Keys.ENTER);
			// Initialize and wait till element(link) became clickable - timeout in 10 seconds
			WebElement firstResult = new WebDriverWait(driver, Duration.ofSeconds(10))
			        .until(ExpectedConditions.elementToBeClickable(By.xpath("//a/h3")));
			// Print the first result
			System.out.println(firstResult.getText());
			
			
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
