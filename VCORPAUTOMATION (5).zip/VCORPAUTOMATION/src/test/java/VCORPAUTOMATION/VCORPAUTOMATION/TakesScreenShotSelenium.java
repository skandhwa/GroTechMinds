package VCORPAUTOMATION.VCORPAUTOMATION;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TakesScreenShotSelenium {

	public static void main(String[] args) throws InterruptedException, IOException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://demoqa.com/buttons");
		Thread.sleep(3000);
		
		TakesScreenshot scrshot=(TakesScreenshot)driver;///step 1
		
		File SrcFile=scrshot.getScreenshotAs(OutputType.FILE);///step 2
		
		File DestFile=new File("D:\\ScreenShot Folder\\TestGrotech2.png");//step 3
		
		FileUtils.copyFile(SrcFile, DestFile);///Step 4
		
		
		
		
		
	}

}
