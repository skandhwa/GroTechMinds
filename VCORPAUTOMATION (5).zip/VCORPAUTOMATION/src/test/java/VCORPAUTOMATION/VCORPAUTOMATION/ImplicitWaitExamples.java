package VCORPAUTOMATION.VCORPAUTOMATION;

public class ImplicitWaitExamples {

	public static void main(String[] args) {
		
		
		

	}

}
