package VCORPAUTOMATION.VCORPAUTOMATION;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandlingMultipleWindows {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://demo.automationtesting.in/Windows.html");
		Thread.sleep(3000);
		String WindowID=	driver.getWindowHandle();
		System.out.println(WindowID);
		
		////Handling Multiple Windows
		
		driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
		driver.findElement(By.xpath("(//button[@class='btn btn-info'])[2]")).click();
		Set <String> S1=driver.getWindowHandles();
		System.out.println(S1);
		
		Iterator <String> I1=S1.iterator();
		while(I1.hasNext())
		{
			String childwindow=    I1.next();
			if(!WindowID.equals(childwindow))
			{
				driver.switchTo().window(childwindow);
			String title=	driver.switchTo().window(childwindow).getTitle();
			System.out.println(title);
				driver.close();
			}
			
			
			
		}
		
		
		driver.switchTo().window(WindowID);
		
		

	}

}
