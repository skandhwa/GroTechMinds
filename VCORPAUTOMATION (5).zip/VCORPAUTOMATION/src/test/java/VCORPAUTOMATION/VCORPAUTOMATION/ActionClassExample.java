package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ActionClassExample {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		Thread.sleep(3000);
		
		Actions act=new Actions(driver);
	WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-13-address']"));
		
		
		act.contextClick(ele).build().perform();
		
		act.doubleClick().build().perform();
		

	}

}
