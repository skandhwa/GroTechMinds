package VCORPAUTOMATION.VCORPAUTOMATION;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SelectClassUageinSelenium {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm");
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,600)");
		
		Select obj=new Select (driver.findElement(By.xpath("//select[@name='continents']")));
		//obj.selectByIndex(4);
		//obj.selectByVisibleText("Africa");
		//obj.selectByValue("Africa");
		
//		Select oSelect=new Select (driver.findElement(By.xpath("//select[@name='selenium_commands']")));
//		if(oSelect.isMultiple()==true)
//		{
////			oSelect.selectByIndex(2);
////			oSelect.selectByIndex(3);
////			oSelect.selectByIndex(4);
//			oSelect.selectByVisibleText("Switch Commands");
//			oSelect.selectByVisibleText("Wait Commands");
//			
//		}
		
		
		
		///////USING SELECTED OPTIONS ////////////////
		
		List<WebElement> li=obj.getOptions();
		for(WebElement a:li)
		{
			String str=a.getText();
			System.out.println(str);
			if(str.equalsIgnoreCase("africa"))
					{
				System.out.println("Test case Passed");
					}
		}
		
		
		//Using getfirst selected options
		
		System.out.println("----This is the next code                ");
		System.out.println();
		System.out.println();
		Select oSelect=new Select (driver.findElement(By.xpath("//select[@name='selenium_commands']")));
		if(oSelect.isMultiple()==true)
		{
			oSelect.selectByIndex(1);
		oSelect.selectByIndex(2);
			oSelect.selectByIndex(3);
			oSelect.selectByIndex(4);	
		}
			WebElement firstoption=oSelect.getFirstSelectedOption();
		String str1=	firstoption.getText();
		System.out.println(str1);
		
		System.out.println();
		System.out.println("This is the third code ");
		
		List<WebElement> li2=oSelect.getAllSelectedOptions();
		for(WebElement b:li2)
		{
		String str3=	b.getText();
		System.out.println(str3);
		}
		
		Thread.sleep(3000);
		
		//oSelect.deselectAll();
		
		oSelect.deselectByIndex(2);
		oSelect.deselectByVisibleText("Wait Commands");
		
		
		
		
		
			
		
		
		
		
		
		
		
		
		
		
		

	}

}
