package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;


public class UsingKeyboardEventsActionClass {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://demoqa.com/text-box");
		
		String address="The Kolkata Municipal Corporation\r\n"
				+ "5, S.N.Banerjee Road,Kolkata 700 013, India\r\n"
				+ "Ph : +91 33 2286-1000 (28 Lines)";
		
		driver.findElement(By.xpath("//textarea[@id='currentAddress']")).sendKeys(address);
		
		
		Actions act=new Actions(driver);
		
		////SELECTED THE CONTENT
		act.keyDown(Keys.CONTROL);
		act.sendKeys("a");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		///COPY THE CONTENT
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("c");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		////PRESS TAB KEY
		act.keyDown(Keys.TAB);
		act.build().perform();
		
		///PASTE THE ADDRESS
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("v");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		
		
		
		
		
		
	WebElement ele=	driver.findElement(By.xpath("//textarea[@id='permanentAddress']"));
String AddressNew=	ele.getText();
Thread.sleep(3000);
System.out.println(AddressNew);

if(address.equalsIgnoreCase(AddressNew))
{
	System.out.println("Test Case Passed");
}

	
	
	//Assert.assertEquals(address, AddressNew);	
//Assert.asse
		
		
		
		
		
		
		
		
		
	}

}
