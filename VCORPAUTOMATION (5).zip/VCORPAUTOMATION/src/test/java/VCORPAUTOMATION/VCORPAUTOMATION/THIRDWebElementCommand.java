package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class THIRDWebElementCommand {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		driver.findElement(By.xpath("//input[@id='vfb-20-0']")).click();
		WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-31-1']"));
		//ele.click();
		 boolean flag= ele.isSelected();
		 Thread.sleep(3000);
		 System.out.println(flag);
		 
//	WebElement ele2=driver.findElement(By.xpath("(//label[@class='vfb-desc'])[1]"));
//	
//String text=	ele2.getText();
//System.out.println(text);


String TextVal=driver.findElement(By.xpath("(//label[@class='vfb-desc'])[1]")).getText();
System.out.println(TextVal);	


String TagValue=driver.findElement(By.xpath("(//label[@class='vfb-desc'])[1]")).getTagName();
System.out.println(TagValue);

String TagValue2=driver.findElement(By.xpath("//input[@id='vfb-31-1']")).getTagName();
System.out.println(TagValue2);

String AttributeValue=driver.findElement(By.xpath("//input[@id='vfb-5']")).getAttribute("type");
System.out.println(AttributeValue);





		 
		 
		 
		
		
		
		
		
		
		
		

	}

}
