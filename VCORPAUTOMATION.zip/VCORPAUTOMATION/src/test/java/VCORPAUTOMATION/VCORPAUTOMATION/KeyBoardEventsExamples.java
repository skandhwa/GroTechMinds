package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KeyBoardEventsExamples {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.toolsqa.com/selenium-webdriver/keyboard-events-in-selenium/");
		Actions act=new Actions(driver);
		act.keyDown(Keys.NUMPAD5);
		
		
		

	}

}
