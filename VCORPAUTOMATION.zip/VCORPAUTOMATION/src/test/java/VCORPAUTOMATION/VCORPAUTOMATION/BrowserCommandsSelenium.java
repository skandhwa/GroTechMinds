package VCORPAUTOMATION.VCORPAUTOMATION;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserCommandsSelenium {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		//GET
		driver.get("https://www.google.com/");
		//GET TITLE
	String title=	driver.getTitle();
	System.out.println(title);
	
	driver.findElement(By.xpath("(//a[@class='gb_v'])[1]")).click();//IGNORE
	Thread.sleep(3000);
	///GET CURRENT URL
	
	String Current_URL=driver.getCurrentUrl();
	System.out.println(Current_URL);
	
	//GET PAGE SOURCE
String PageSource=	driver.getPageSource();
System.out.println(PageSource);
Thread.sleep(6000);

////DRIVER CLOSE AND QUIT 


driver.quit();

	
	
	

	
	
	
	
	}

}
