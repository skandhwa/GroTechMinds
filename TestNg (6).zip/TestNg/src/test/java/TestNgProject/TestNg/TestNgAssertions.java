package TestNgProject.TestNg;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestNgAssertions {
	
	
	@Test
	public void testngAssertions()
	{
//		int x=7;
//		int y=5;
//		Assert.assertNotEquals(x, y);
//		System.out.println("These two values are equals");
		
		int x=25;
		int y=50/2;//25
		
		//Assert.assertTrue(x==y);///false
		
//		Assert.assertFalse(x==y);//25==25
//		
//		int z=x+y;
//		System.out.println(z);
//		
//		System.out.println("These two values are  equal");
		
//		
//		SoftAssert obj= new SoftAssert();
//		obj.assertTrue(false);
//		System.out.println("Hello");
		
		
		
		
		
		
		
		
		
		
		
	}

}
