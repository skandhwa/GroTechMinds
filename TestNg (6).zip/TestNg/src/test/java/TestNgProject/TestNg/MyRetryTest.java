package TestNgProject.TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MyRetryTest {
	
	public WebDriver driver;
	@Test(retryAnalyzer=TestNgProject.TestNg.RetryTestcase.class)
	public void test()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Grotechminds");
		driver.findElement(By.xpath("(//input[@value='Google Search'])[2]")).click();
	}
	
	@Test(retryAnalyzer=TestNgProject.TestNg.RetryTestcase.class)
	public void test2()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Grotechminds");
		driver.findElement(By.xpath("(//input[@value='Google Search'])[9]")).click();
	}

}
