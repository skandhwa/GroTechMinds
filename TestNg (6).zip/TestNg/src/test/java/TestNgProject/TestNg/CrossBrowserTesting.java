package TestNgProject.TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserTesting {
	
	public WebDriver driver;
	@Parameters("browser")
	
	@BeforeClass
	
	public void beforeTest(String browser)
	{
		if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
		}
		
		else if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
		}
		
		driver.get("https://www.google.com/");
		
	}
	
	@Test
	
	public void login()
	{
		driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Grotechminds");
		driver.findElement(By.xpath("(//input[@value='Google Search'])[2]")).click();
		
		
	}
		
		
		
		
		
		
		
		
	
	

}
