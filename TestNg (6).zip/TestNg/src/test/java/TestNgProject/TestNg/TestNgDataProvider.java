package TestNgProject.TestNg;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProvider {
	
	@DataProvider(name="abc")
	public Object[][] method()
	{
		return new Object[][] {{"First-Value"},{"Second-Value"}};
		
	}
	
	
	
	@Test(dataProvider="abc")
	public void myTest(String Val)
	{
		System.out.println("Passed Parameter is"+Val);
	}

}
