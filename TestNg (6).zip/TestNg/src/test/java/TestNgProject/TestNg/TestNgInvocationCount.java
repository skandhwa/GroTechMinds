package TestNgProject.TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgInvocationCount {
	public WebDriver driver;
	
	@Test
	public void TestPage()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.xpath("//textarea[@class='gLFyf']")).sendKeys("Grotechminds");
		driver.findElement(By.xpath("(//input[@value='Google Search'])[2]")).click();
	}
	
	@Test(invocationCount=5)
	public void TestPage2()
	{
		driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
	}
	
	@Test(invocationCount=5)
	public void TestPage3()
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		
	}

}
