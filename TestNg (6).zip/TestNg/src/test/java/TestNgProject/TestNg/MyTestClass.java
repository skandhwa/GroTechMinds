package TestNgProject.TestNg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenerTestNg.class)
public class MyTestClass {
	
	WebDriver driver=new ChromeDriver();
	
	@Test
	public void closebrowser()
	{
		driver.close();
		Reporter.log("I am closing the browser");
	}
	
	@Test
	public void OpenBrowser()
	{
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		Assert.assertEquals("abcd", "title");
	}
	
	
	

}
