package TestNgProject.TestNg;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertionExample {
	
	@Test
	public void softassertex()
	{
		SoftAssert obj=new SoftAssert();
		obj.assertEquals(5, 3);
		System.out.println("My test Case is failed");
		
		
	}

}
