package MyCucumberProject.CucumberNew.FeatureFiles;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features="src/test/java/MyCucumberProject/CucumberNew/FeatureFiles/"
		,glue={"stepdefinition"}
		,monochrome=true,
				dryRun=false,
				tags="@sanity or @smoke"
		
		
		
		)






public class testrunner {

}
