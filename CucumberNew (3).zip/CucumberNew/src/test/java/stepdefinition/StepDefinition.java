package stepdefinition;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	@Before
	public void test()
	{
		System.out.println("I am Before suite");
	}
	
	
	@Before("@first")
	public void beforetestsuite()
	{
		System.out.println("I am Before first");
	}
	
	@After("@second")
	public void closeconnectionafterscenario()
	{
		System.out.println("I am After Second");
		
	}
	@After("@first")
	public void closeconnectionafterscenario1()
	{
		System.out.println("I am After first");
	}
	
	@Before("@second")
	public void BeforeTestscenario2()
	{
		System.out.println("I am before second test");
	}
	
	@After
	public void afteralltest()
	{
		System.out.println("I will be always after every scenario");
	}
	
	
	
	
	@Given("User opens the facebook URL in the browser")
	public void user_opens_the_facebook_url_in_the_browser() {
		
		System.out.println("I am feature 2");
	    
	}

	@Given("User enters the user id in the userid field")
	public void user_enters_the_user_id_in_the_userid_field() {
		
		System.out.println("I am feature 3");
	    
	}

	@Given("User enters the password in the password field")
	public void user_enters_the_password_in_the_password_field() {
		System.out.println("I am feature 4");
	}

	@When("User clicks on login button")
	public void user_clicks_on_login_button() {
		System.out.println("I am feature 5");
	    
	}

	@Then("User will be navigated to facebook home page")
	public void user_will_be_navigated_to_facebook_home_page() {
		System.out.println("I am feature 6");
	}

	@Given("User enters the skan1234 in the userid field")
	public void user_enters_the_skan1234_in_the_userid_field() {
		System.out.println("I am feature 7");
	   
	}

	@Given("User enters the test@{int} in the password field")
	public void user_enters_the_test_in_the_password_field(Integer int1) {
		System.out.println("I am feature 8");
	}
	
	@Then("User verifies the title")
	public void user_verifies_the_title() {
		System.out.println("I am feature 9");
	    
	}

	
	
	

}
