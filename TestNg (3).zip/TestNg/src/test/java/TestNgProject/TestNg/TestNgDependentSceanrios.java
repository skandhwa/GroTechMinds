package TestNgProject.TestNg;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgDependentSceanrios {
	
	
	@Test
	public void OpenBrowser()
	{
		int x=9/0;
		System.out.println(x);
		System.out.println("I am Open Browser page");
				
		Reporter.log("This is Open Browser Page");
	}
	
	
	@Test(dependsOnMethods= {"OpenBrowser()"})
	public void SignIn()
	{
		System.out.println("I am Sign In page");
		Reporter.log("This is Sign In Page");
	}
	
	@Test(dependsOnMethods= {"SignIn()","OpenBrowser()"})
	public void SearchProduct()
	{
		System.out.println("I am Search a product page");
		Reporter.log("This is Search a product Page");
	}
	
	@Test
	public void display()
	{
		System.out.println("I am not dependent on anyone");
	}
	
	


}
