package Practice;

import java.util.LinkedList;

public class LinkedListExplaination {

	public static void main(String[] args) {
	
		LinkedList<String> li=new LinkedList<String>();
		

	}

}
