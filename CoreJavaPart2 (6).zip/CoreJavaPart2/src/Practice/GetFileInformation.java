package Practice;

import java.io.File;
import java.io.IOException;

public class GetFileInformation {

	public static void main(String[] args) throws IOException {
		
		File f1=new File("D:\\File Demo\\New4.txt");
		boolean flag=f1.createNewFile();
		System.out.println(flag);
		
		
		if(f1.exists())
		{
			System.out.println	(f1.getName());
			System.out.println	(f1.getAbsolutePath());
			System.out.println	(f1.canWrite());
			System.out.println	(f1.canRead());
			System.out.println	(f1.length());
			
		}
		
		else
		{
			System.out.println("File does not exist");
		}
		
		

	}

}
