package Practice;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExamples {

	public static void main(String[] args) {
		
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		
		//ArrayList<String> li2=new ArrayList<String>();
		
		
		li.add(4);
		li.add(56);
		li.add(49);
		
		////FIRST WAY OF ITERATING THROUGH AN ARRAY LIST
		
//		Iterator itr=li.iterator();
//		
//		while(itr.hasNext())
//		{
//			System.out.print(itr.next()+"  ");//4//56//49
//		}
//		
		
		///SECOND WAY
		
	//	System.out.println(li);
		
		///THIRD WAY
		for(int x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		
	}

}
