package Practice;

import java.util.HashMap;
import java.util.Map;

public class MapUpdateElement {

	public static void main(String[] args) {
		
		Map<String,String> mp=new HashMap <String,String>();	
		boolean flag=mp.isEmpty();
		System.out.println(flag);
		
		mp.put("A", "Ramesh");
		mp.put("B", "Saurabh");
		mp.put("C", "manish");
		
		mp.put("D", "Sukesh");
		
		for(Map.Entry var:mp.entrySet())
		{
			System.out.print(var.getKey()+" ");
			System.out.println(var.getValue());
		}
		
		mp.replace("D", "Harish");
		
		System.out.println("After Updating the Map");
		
		for(Map.Entry var:mp.entrySet())
		{
			System.out.print(var.getKey()+" ");
			System.out.println(var.getValue());
		}

	String str=	mp.get("A");
	System.out.println(str);
	
	boolean flag1=mp.isEmpty();
	System.out.println(flag1);
boolean flag2=	mp.containsKey("D");
	System.out.println(flag2);
	
	
	
		
	}

}
