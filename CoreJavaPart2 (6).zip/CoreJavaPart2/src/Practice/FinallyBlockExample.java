package Practice;

public class FinallyBlockExample {

	public static void main(String[] args) {
		
		try
		{
		int x=25/0;
		System.out.println(x);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		
		finally
		{
			int x=10;
			int y=10;
			int z=x+y;
			System.out.println("The Finally clause is getting executed" +z);
		}
		
		

	}

}
