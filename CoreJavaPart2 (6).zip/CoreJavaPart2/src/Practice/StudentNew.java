package Practice;

import java.util.ArrayList;
import java.util.Collections;

class Student4 implements Comparable<Student4>
{
	int roll;
	String name;
	int age;
	Student4(int roll,String name,int age)
	{
		this.roll=roll;
		this.name=name;
		this.age=age;
	}
	
	public int compareTo(Student4 st)
	{
		if(age==st.age)
		
			return 0;
		else if(age>st.age)
	return 1;
		else
			return -1;
		
	}

}
public class StudentNew {

	public static void main(String[] args) {
		
	    ArrayList<Student4> al=new ArrayList<Student4>();
	    
	    al.add(new Student4 (100,"Saurabh",56));
	    al.add(new Student4 (106,"Saurabh",23));
	    al.add(new Student4 (108,"Saurabh",21));
	    
	    Collections.sort(al);
	    
	   for(Student4 st:al)
	   {
		   System.out.print(st.roll+" ");
		   System.out.print(st.name+" ");
		   System.out.print(st.age+" ");
	   }
		
		
		

	}

}
