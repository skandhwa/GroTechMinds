package Practice;

import java.util.Arrays;

public class MethodsofArray {

	public static void main(String[] args) {
		
		int a[]= {10,20,30,40};
		int b[]= {10,20,30,40,50};
		
	boolean flag=	Arrays.equals(a,b);
	
	
	
	System.out.println(flag);
		

	}

}
