package Practice;

public class StringMethodsNew {

	public static void main(String[] args) {
		
		///Substring
		String str1="LearnJava";
	String str2=	str1.substring(5);
	System.out.println(str2);
	
	
	String str3=	str1.substring(7,7);
	System.out.println(str3);
	
	//String Contains Method
	
	String str5="SaurabhTeachesSeleniumand";
boolean flag=	str5.contains(" ");
System.out.println(flag);
	
	
		

	}

}
