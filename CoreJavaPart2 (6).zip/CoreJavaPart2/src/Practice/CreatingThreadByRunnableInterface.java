package Practice;

public class CreatingThreadByRunnableInterface implements Runnable {
	
	public void run()
	{
		System.out.println("Thread is running");
	}

	public static void main(String[] args) {
		
		CreatingThreadByRunnableInterface obj=new CreatingThreadByRunnableInterface();
		
		
		Thread t=new Thread(obj);
		
		
		
		t.start();
		

	}

}
