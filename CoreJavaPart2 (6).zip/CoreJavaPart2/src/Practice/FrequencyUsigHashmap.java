package Practice;

import java.util.HashMap;
import java.util.Map;

public class FrequencyUsigHashmap {

	public static void main(String[] args) {
		
		String str="Neon";
		String str1=str.toUpperCase();
		
		char []strArray =str1.toCharArray();
		
	    Map<Character,Integer> mp=new HashMap<Character,Integer>();
	    
	    for(char c:strArray)////
	    {
	    	if(mp.containsKey(c))
	    	{
	    		mp.put(c, mp.get(c)+1);////mp.put(N,1+1)
	    	}
	    	else
	    		mp.put(c,1);
	    	
	    }
	    
	    
	    for(Map.Entry m:mp.entrySet())
	    {
	    	System.out.print(m.getKey()+" ");
	    	System.out.println(m.getValue());
	    }
	    
	    
		

	}

}
