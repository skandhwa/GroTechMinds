package Practice;

public class StringFurtherMethods {

	public static void main(String[] args) {
		
		String str1="SaURaBh";
		
		String str5=str1.toLowerCase();
		System.out.println(str5);
		
		String str2="JAVA";
		
		String str3="python";
		String str4="pyth on";
		
		boolean flag=str3.equalsIgnoreCase(str4);
		System.out.println(flag);
		
	}

}
