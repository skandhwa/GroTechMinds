package Practice;

import java.util.HashSet;
import java.util.Set;

public class HashSetRemove {

	public static void main(String[] args) {
		
		Set<Integer> S1=new HashSet<Integer>();
		S1.add(45);
		S1.add(67);
		S1.add(15);
		S1.add(17);
		S1.add(25);
		S1.add(47);
		
		for(int y:S1)
		{
			System.out.println(y);
		}
		
		
		S1.remove(15);
		S1.remove(47);
		
		System.out.println("After deleting the elements are ");
		System.out.println();
		
		for(int z:S1)
		{
			System.out.println(z);
		}
		

	}

}
