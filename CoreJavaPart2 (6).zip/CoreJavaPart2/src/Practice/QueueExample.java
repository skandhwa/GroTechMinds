package Practice;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		
		PriorityQueue<String> Q=new PriorityQueue<String>();
		
		Q.add("Amit");
		Q.add("Vijay");
		Q.add("Jai");
		Q.add("Rahul");
		Q.add("Bimal");
		
		System.out.println(Q);
		
		Q.remove();
		
		System.out.println(Q);
		
		Q.poll();
		
		System.out.println(Q);
		
		Q.peek();
		
		System.out.println(Q);
		
		
		

}
	
}
