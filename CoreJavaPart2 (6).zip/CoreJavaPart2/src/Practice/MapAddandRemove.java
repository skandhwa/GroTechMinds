package Practice;

import java.util.HashMap;
import java.util.Map;

public class MapAddandRemove {

	public static void main(String[] args) {
		
		

		Map<Integer,String> mp=new HashMap <Integer,String>();		
		mp.put(6, "Ramesh");
		mp.put(1, "Saurabh");
		mp.put(4, "manish");
		
		mp.put(7, "Sukesh");
		
		mp.putIfAbsent(7, "Rakesh");
		
		  //System.out.println(mp);  
		
		mp.remove(7);
		  
		  
		for(Map.Entry var: mp.entrySet())
		{
			
			System.out.print(var.getKey()+" ");
			System.out.println(var.getValue());
			
		}
		
		Map<Integer,String> mp2=new HashMap <Integer,String>();
		
		mp2.putAll(mp);
		
		for(Map.Entry var: mp2.entrySet())
		{
			
			System.out.print(var.getKey()+" ");
			System.out.println(var.getValue());
			
		}
		

	}

}
