package Practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Student5 
{
	int roll;
	String name;
	int age;
	Student5(int roll,String name,int age)
	{
		this.roll=roll;
		this.name=name;
		this.age=age;
	}

	
	
class AgeComparator implements Comparator<Student5>
{
	public int compare(Student5 s1,Student5 s2)
	{
		if(s1.age==s2.age)
		{
			return 0;
		}
		if(s1.age>s2.age)
		{
			return 1;
		}
		
		else return -1;
	}
}


class rollcomparator implements Comparator<Student5>
{
	public int compare(Student5 s1,Student5 s2)
	{
		if(s1.roll==s2.roll)
		{
			return 0;
		}
		if(s1.roll>s2.roll)
		{
			return 1;
		}
		
		else return -1;
	}
}
public class ComparatorProgram {

	public static void main(String[] args) {
		
ArrayList<Student5> al=new ArrayList<Student5>();
	    
	    al.add(new Student5 (100,"Saurabh",56));
	    al.add(new Student5 (106,"manish",23));
	    al.add(new Student5 (108,"ramesh",21));
	    
	    Collections.sort(al,new AgeComparator());
		
		
		
		
		
		

	}

}

}
