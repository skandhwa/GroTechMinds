package Practice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HashSetAddAll {

	public static void main(String[] args) {
		
		Set<Integer> S1=new HashSet<Integer>();
		S1.add(45);
		S1.add(67);
		S1.add(15);
		S1.add(17);
		S1.add(25);
		S1.add(47);
		
		ArrayList<Integer> A=new ArrayList<Integer>();
		A.add(45);
		A.add(95);
		A.add(76);
		A.add(25);
		
		
		S1.addAll(A);
		
		
		
		
		for(int y:S1)
		{
			System.out.println(y);
		}
		
		
		System.out.println("Clearing the Set");
		S1.clear();
		
		for(int y:S1)
		{
			System.out.println(y);
		}
		
		
		
		System.out.println("Merging Set into ArrayList");
		System.out.println();
		System.out.println();
		
		
		A.addAll(S1);
		
		for(int z:A)
		{
			System.out.println(z);
		}
		
		
		
		
		
		
		
		
		

	}

}
