package Practice;

public class ArrayExamples {

	public static void main(String[] args) {
		
		int a[]=new int[400];//firstway of array declaration
		
		int b[]= {23,12,54,67,89,54,23,67,54,67,98,65};///5
		
		a[0]=12;
		a[1]=34;
		a[2]=46;
		a[3]=56;
		a[4]=34;
		
		for(int i=0;i<a.length;i++)///i=0,i<5//i=1,1<5//i=2,2<5
			
		{
			System.out.println(a[i]);//a[0]//a[1]//a[2]
		}
		
		
for(int i=0;i<b.length;i++)///i=0,i<5//i=1,1<5//i=2,2<5
			
		{
			System.out.println(b[i]);//a[0]//a[1]//a[2]
		}
		
		

	}

}
