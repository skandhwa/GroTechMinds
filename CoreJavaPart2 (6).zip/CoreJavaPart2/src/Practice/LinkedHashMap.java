package Practice;

import java.util.Map;
import java.util.TreeMap;


public class LinkedHashMap {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(100, "Manish");
		mp.put(108, "Rakesh");
		mp.put(105, "Harish"); 
		mp.put(76, "Rahul");
		
		for(Map.Entry v:mp.entrySet())
		{
			System.out.print(v.getKey()+" ");
			System.out.println(v.getValue());
		}
		
		System.out.println();
		System.out.println();
//		System.out.println("The Descending Map is");
//		
//		System.out.println(mp.descendingMap());
		
		
	System.out.println(mp.headMap(105,true));	
	
	System.out.println(mp.tailMap(100,true));
		
		
		

	}

}
