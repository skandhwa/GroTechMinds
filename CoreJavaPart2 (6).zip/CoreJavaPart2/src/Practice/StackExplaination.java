package Practice;

import java.util.Stack;

public class StackExplaination {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<>();
	boolean flag=	stk.empty();
	System.out.println(flag);
	
	stk.push(70);
	stk.push(65);
	stk.push(89);
	
	for(int x:stk)
	{
		System.out.println(x);
	}
	
	stk.pop();
	System.out.println("p------------Stack after deleting one element is ------------");
	
	for(int x:stk)
	{
		System.out.println(x);
	}

	}

}
