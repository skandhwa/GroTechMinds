package Practice;

import java.util.Arrays;

public class ArrayEquals {

	public static void main(String[] args) {
		
		int a[]= {34,5,6,7};
		int b[]= {34,5,9,7};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);

	}

}
