package Practice;

import java.util.HashMap;
import java.util.Map;

public class MapFirstExample {

	public static void main(String[] args) {
		
		
		Map<Integer,String> mp=new HashMap <Integer,String>();
		
		mp.put(1, "Saurabh");
		mp.put(4, "manish");
		mp.put(6, "Ramesh");
		mp.put(7, "Sukesh");
		
		
		
		//System.out.println(mp);
		
		
for(Map.Entry v:mp.entrySet())
{
	System.out.print(v.getKey());
	System.out.print(v.getValue());
}




	}

}
